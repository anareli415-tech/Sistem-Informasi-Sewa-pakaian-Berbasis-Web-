<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Http\Request;

// --- IMPORT MODEL ---
use App\Models\Pakaian;
use App\Models\Transaksi;
use App\Models\User;
use App\Models\Toko;

// --- IMPORT CONTROLLER ---
use App\Http\Controllers\LoginController;
use App\Http\Controllers\RegisterController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\TransaksiController;
use App\Http\Controllers\RiwayatController;
use App\Http\Controllers\RegisterTokoController;
use App\Http\Controllers\KategoriController;
use App\Http\Controllers\PakaianController;
use App\Http\Controllers\LaporanController;
use App\Http\Controllers\PembayaranController;
use App\Http\Controllers\PengembalianController;

/*
|--------------------------------------------------------------------------
| GUEST ROUTES
|--------------------------------------------------------------------------
*/
Route::middleware('guest')->group(function () {
    Route::get('/', function () { return redirect()->route('login'); });
    Route::get('/login', [LoginController::class, 'index'])->name('login');
    Route::post('/login', [LoginController::class, 'proses'])->name('login.proses');
    Route::get('/register', [RegisterController::class, 'index'])->name('register');
    Route::post('/register', [RegisterController::class, 'store'])->name('register.store');
});

/*
|--------------------------------------------------------------------------
| AUTH ROUTES
|--------------------------------------------------------------------------
*/
Route::middleware('auth')->group(function () {
    
    // --- DASHBOARD REDIRECTOR ---
    Route::get('/dashboard', function() {
        $role = auth()->user()->role;
        if ($role == 'pemilik') return redirect()->route('dashboard.pemilik');
        if ($role == 'penyedia') return redirect()->route('dashboard.penyedia');
        return redirect()->route('dashboard.pelanggan');
    })->name('dashboard');

    /* --- 1. FITUR KHUSUS PEMILIK (ADMIN) --- */
    Route::get('/dashboard/pemilik', function () {
        $totalUser = User::count();
        $totalPenyedia = User::where('role', 'penyedia')->count();
        $totalTransaksi = Transaksi::whereNotIn('status', ['WAIT', 'BATAL'])->count();
        $totalOmset = Transaksi::whereNotIn('status', ['WAIT', 'BATAL'])->sum('total_sewa');
        $penyediaBaru = User::where('role', 'penyedia')->latest()->take(5)->get();
        $grafik = Transaksi::whereNotIn('status', ['WAIT', 'BATAL'])
                    ->get()->groupBy(fn($d) => Carbon::parse($d->tgl_pesan)->format('M'));

        return view('dashboard.pemilik', [
            'totalUser' => $totalUser, 'totalPenyedia' => $totalPenyedia,
            'totalTransaksi' => $totalTransaksi, 'totalOmset' => $totalOmset,
            'penyediaBaru' => $penyediaBaru, 'bulan' => $grafik->keys()->toArray(),
            'dataTransaksi' => $grafik->map->count()->values()->toArray()
        ]);
    })->name('dashboard.pemilik');

    Route::get('/admin/laporan-omset', function (Request $request) {
        $tglMulai = $request->tgl_mulai;
        $tglSelesai = $request->tgl_selesai;
        $query = Transaksi::whereIn('status', ['DIKEMBALIKAN', 'SELESAI', 'DIBAYAR']);
        if ($tglMulai && $tglSelesai) { $query->whereBetween('tgl_pesan', [$tglMulai, $tglSelesai]); }
        $transaksiSelesai = $query->get();
        $totalBruto = $transaksiSelesai->sum('total_sewa');
        $ppnRate = 0.10; 
        $pendapatanPlatform = $totalBruto * $ppnRate;
        $laporanToko = Toko::with(['user'])->get()->map(function($toko) use ($ppnRate, $tglMulai, $tglSelesai) {
            $qOmset = Transaksi::whereHas('pakaian', function($q) use ($toko) { $q->where('user_id', $toko->user_id); })
                        ->whereIn('status', ['DIKEMBALIKAN', 'SELESAI', 'DIBAYAR']);
            if ($tglMulai && $tglSelesai) { $qOmset->whereBetween('tgl_pesan', [$tglMulai, $tglSelesai]); }
            $omsetToko = $qOmset->sum('total_sewa');
            return [
                'nama_toko' => $toko->nama_toko, 'owner' => $toko->user->name ?? 'N/A',
                'omset_bruto' => $omsetToko, 'ppn_platform' => $omsetToko * $ppnRate,
                'netto_toko' => $omsetToko - ($omsetToko * $ppnRate),
            ];
        });
        return view('pemilik.laporan_omset', compact('totalBruto', 'pendapatanPlatform', 'laporanToko', 'tglMulai', 'tglSelesai'));
    })->name('pemilik.laporan_omset');

    Route::get('/manajemen-user', function() {
        $users = User::with('toko')->where('id', '!=', auth()->id())->latest()->paginate(10);
        return view('pemilik.user', compact('users'));
    })->name('users.index');

    Route::delete('/manajemen-user/{id}', function($id) {
        User::findOrFail($id)->delete();
        return back()->with('success', 'Pengguna berhasil dihapus!');
    })->name('users.destroy');

    Route::get('/daftar-toko', function () {
        $tokos = Toko::with(['user'])->withCount('pakaian')->latest()->paginate(10);
        return view('pemilik.daftar_toko', compact('tokos'));
    })->name('toko.daftar');

    /* --- 2. FITUR KHUSUS PENYEDIA --- */
    Route::get('/laporan-keuangan', [LaporanController::class, 'index'])->name('laporan.index');
    Route::get('/dashboard/penyedia', function () {
        $totalStok = Pakaian::where('user_id', auth()->id())->sum('stok') ?? 0;
        $transaksiPenyedia = Transaksi::whereHas('pakaian', function($q) { $q->where('user_id', auth()->id()); })
                                ->whereNotIn('status', ['WAIT', 'BATAL']);
        $totalPenyewaan = $transaksiPenyedia->count();
        $totalOmset = $transaksiPenyedia->sum('total_sewa');
        $transaksiGrafik = $transaksiPenyedia->where('tgl_pesan', '>=', Carbon::now()->subMonths(6))->get();
        $dataFormatted = $transaksiGrafik->groupBy(fn($date) => Carbon::parse($date->tgl_pesan)->format('M'))
                            ->map(fn($group) => $group->sum('total_sewa'));
        return view('dashboard.penyedia', [
            'totalStok' => $totalStok, 'totalPenyewaan' => $totalPenyewaan, 'totalOmset' => $totalOmset,
            'bulan' => $dataFormatted->keys()->toArray(), 'omsetPerBulan' => $dataFormatted->values()->toArray()
        ]);
    })->name('dashboard.penyedia');

    Route::get('/pakaian/{id}/riwayat', [TransaksiController::class, 'riwayatPakaian'])->name('pakaian.riwayat');
    Route::resource('pakaian', PakaianController::class);

    /* --- 3. FITUR TRANSAKSI (WAJIB ADA INI) --- */
    Route::get('/transaksi', [TransaksiController::class, 'index'])->name('transaksi.index');
    Route::post('/transaksi/store', [TransaksiController::class, 'store'])->name('transaksi.store'); // FIX ERROR 500/Route Not Found
    Route::patch('/transaksi/{id}/update-status', [TransaksiController::class, 'updateStatus'])->name('transaksi.updateStatus');

    /* --- 4. FITUR UMUM / PELANGGAN --- */
    Route::get('/dashboard/pelanggan', [DashboardController::class, 'index'])->name('dashboard.pelanggan');
    Route::post('/logout', [LoginController::class, 'logout'])->name('logout');
    Route::get('/profile', [DashboardController::class, 'profile'])->name('profile');
    Route::post('/profile', [DashboardController::class, 'updateProfile'])->name('profile.update');
    
    // KATEGORI FIX
    Route::get('/kategori', [KategoriController::class, 'index'])->name('kategori.index');
    Route::get('/kategori/{slug}', [KategoriController::class, 'show'])->name('kategori.show');

    Route::get('/riwayat', [RiwayatController::class, 'index'])->name('riwayat.index');
    Route::get('/register-toko', [RegisterTokoController::class, 'create'])->name('register.toko');
    Route::post('/register-toko', [RegisterTokoController::class, 'store'])->name('register.toko.store');
    
    Route::get('/pembayaran/{id}', [PembayaranController::class, 'index'])->name('pembayaran.index');
    Route::post('/pembayaran/proses', [PembayaranController::class, 'bayar'])->name('pembayaran.bayar');
    Route::get('/pengembalian', [PengembalianController::class, 'index'])->name('pengembalian.index');
    Route::post('/pengembalian/store', [PengembalianController::class, 'store'])->name('pengembalian.store');

    Route::middleware(['auth'])->group(function () {
    Route::post('/profile/update', [ProfileController::class, 'update'])->name('profile.update');
});
});