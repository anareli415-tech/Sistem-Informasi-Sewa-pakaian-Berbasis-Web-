@extends('layout.template')
@section('title','Home - Rent Style')

@section('content')
    
