<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Daftar RFA Store - Mulai Petualangan Fashionmu</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="{{ asset('assets/css/bootstrap.min.css')}}" rel="stylesheet">

    <style>
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: #ffffff;
            overflow-x: hidden;
        }

        .register-container { min-height: 100vh; }

        /* Sisi Kanan: Visual Branding */
        .visual-section {
            background: linear-gradient(135deg, rgba(255, 69, 0, 0.9), rgba(255, 140, 0, 0.9)), 
                        url('https://images.pexels.com/photos/1884581/pexels-photo-1884581.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1');
            background-size: cover;
            background-position: center;
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: center;
            padding: 80px;
        }

        .text-orange { color: #FF8C00; }
        .bg-orange-gradient { background: linear-gradient(90deg, #FF8C00, #FF4500); }

        .btn-orange {
            background: linear-gradient(90deg, #FF8C00, #FF4500);
            color: white; border: none; transition: 0.3s;
        }
        .btn-orange:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(255, 69, 0, 0.3);
            color: white;
        }

        .form-control, .form-select {
            border-radius: 12px;
            padding: 12px 15px;
            border: 1px solid #eee;
            background-color: #f8f9fa;
        }

        .form-control:focus, .form-select:focus {
            box-shadow: none;
            border-color: #FF8C00;
            background-color: #fff;
        }

        .input-group-text {
            border-radius: 12px 0 0 12px;
            border: none;
            background-color: #f8f9fa;
        }

        @media (max-width: 991px) {
            .visual-section { display: none; }
        }
    </style>
</head>
<body>

<div class="container-fluid p-0 register-container">
    <div class="row g-0 min-vh-100">
        
        <div class="col-lg-5 d-flex align-items-center justify-content-center bg-white p-4 p-sm-5">
            <div class="w-100" style="max-width: 450px;">
                
                <div class="mb-4">
                    <a href="{{ url('/') }}" class="text-decoration-none">
                        <h2 class="fw-bold text-orange mb-1">RFA Store</h2>
                    </a>
                    <h4 class="fw-bold text-dark">Buat Akun Baru</h4>
                    <p class="text-muted small">Bergabunglah dan temukan gaya terbaikmu hari ini.</p>
                </div>

                {{-- ALERTS --}}
                @if (session('success'))
                    <div class="alert alert-success rounded-4 small border-0 shadow-sm">
                        <i class="fas fa-check-circle me-2"></i> {{ session('success') }}
                    </div>
                @endif

                @if ($errors->any())
                    <div class="alert alert-danger rounded-4 small border-0 shadow-sm">
                        <ul class="mb-0">
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif

                <form action="{{ route('register.store') }}" method="POST">
                    @csrf

                    {{-- Pilih Role --}}
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-secondary">Daftar Sebagai</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fa fa-user-tag text-muted"></i></span>
                            <select name="role" class="form-select border-0" id="floatingRole" onchange="toggleFields()">
                                <option value="pelanggan" {{ old('role')=='pelanggan' ? 'selected':'' }}>Pelanggan (Ingin Menyewa)</option>
                                <option value="penyedia" {{ old('role')=='penyedia' ? 'selected':'' }}>Penyedia (Punya Toko)</option>
                            </select>
                        </div>
                    </div>

                    {{-- Nama Pelanggan --}}
                    <div class="mb-3" id="fieldNama">
                        <label class="form-label small fw-bold text-secondary">Nama Lengkap</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fa fa-user text-muted"></i></span>
                            <input type="text" name="nama" class="form-control border-0" placeholder="Masukkan nama Anda" value="{{ old('nama') }}">
                        </div>
                    </div>

                    {{-- Nama Toko --}}
                    <div class="mb-3 d-none" id="fieldToko">
                        <label class="form-label small fw-bold text-orange">Nama Toko / Bisnis</label>
                        <div class="input-group">
                            <span class="input-group-text bg-orange-light"><i class="fa fa-store text-orange"></i></span>
                            <input type="text" name="nama_toko" class="form-control border-0" placeholder="Contoh: Rent Kebaya Mewah" value="{{ old('nama_toko') }}">
                        </div>
                    </div>

                    {{-- Email --}}
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-secondary">Alamat Email</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fa fa-envelope text-muted"></i></span>
                            <input type="email" name="email" class="form-control border-0" placeholder="name@example.com" value="{{ old('email') }}">
                        </div>
                    </div>

                    {{-- Password --}}
                    <div class="mb-4">
                        <label class="form-label small fw-bold text-secondary">Kata Sandi</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fa fa-lock text-muted"></i></span>
                            <input type="password" name="password" class="form-control border-0" placeholder="Minimal 8 karakter">
                        </div>
                    </div>

                    <button type="submit" class="btn btn-orange w-100 py-3 rounded-pill fw-bold shadow-sm mb-4">
                        Daftar Sekarang
                    </button>

                    <p class="text-center text-muted mb-0">
                        Sudah punya akun? 
                        <a href="{{ route('login') }}" class="text-orange fw-bold text-decoration-none">Masuk di sini</a>
                    </p>
                </form>
            </div>
        </div>

        <div class="col-lg-7 visual-section d-none d-lg-flex text-end">
            <div class="ms-auto" style="max-width: 500px;">
                <h1 class="display-4 fw-bold mb-3">Jadilah Bagian dari <span class="text-dark">RFA Store</span></h1>
                <p class="fs-5 opacity-90 mb-5">
                    Bergabunglah dengan ribuan pengguna lainnya. Sewa pakaian impianmu atau mulai hasilkan uang dengan menyewakan koleksimu.
                </p>
                
                <div class="row g-4 text-start mt-4">
                    <div class="col-6">
                        <div class="p-3 rounded-4" style="background: rgba(255,255,255,0.1); backdrop-filter: blur(5px);">
                            <i class="fa fa-shield-alt fa-2x mb-2 text-dark"></i>
                            <h6 class="fw-bold">Transaksi Aman</h6>
                            <small class="opacity-75">Sistem pembayaran yang terverifikasi.</small>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="p-3 rounded-4" style="background: rgba(255,255,255,0.1); backdrop-filter: blur(5px);">
                            <i class="fa fa-tags fa-2x mb-2 text-dark"></i>
                            <h6 class="fw-bold">Banyak Pilihan</h6>
                            <small class="opacity-75">Ribuan koleksi dari berbagai toko.</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<script>
function toggleFields() {
    const role = document.getElementById('floatingRole').value;
    const fieldToko = document.getElementById('fieldToko');
    const fieldNama = document.getElementById('fieldNama');
    
    if (role === 'penyedia') {
        fieldToko.classList.remove('d-none');
        fieldNama.classList.add('d-none');
    } else {
        fieldToko.classList.add('d-none');
        fieldNama.classList.remove('d-none');
    }
}
document.addEventListener('DOMContentLoaded', toggleFields);
</script>

<script src="{{ asset('assets/js/bootstrap.bundle.min.js')}}"></script>
</body>
</html>