@extends('layout.app')

@section('title', 'Kategori Pakaian')

@section('content')
<div class="container py-5">
    {{-- Baris Tombol Kembali & Judul --}}
    <div class="d-flex justify-content-start mb-4">
        <a href="{{ url('/dashboard') }}" class="btn btn-back-custom btn-sm rounded-pill px-4 shadow-sm">
            <i class="fas fa-arrow-left me-2"></i> Kembali ke Dashboard
        </a>
    </div>

    <div class="row mb-5">
        <div class="col-12 text-center">
            <h2 class="fw-bold text-uppercase" style="letter-spacing: 3px; color: #333;">
                Koleksi <span style="background: linear-gradient(90deg, #FF8C00, #FF4500); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">Kategori</span>
            </h2>
            <p class="text-muted">Pilih jenis pakaian yang ingin Anda sewa untuk momen spesial</p>
            <div class="mx-auto" style="width: 60px; height: 4px; background: linear-gradient(90deg, #FF8C00, #FF4500); border-radius: 10px;"></div>
        </div>
    </div>

    <div class="row g-4">
        @php
            $kategoriImages = [
                'formal'            => 'https://images.pexels.com/photos/1342609/pexels-photo-1342609.jpeg?auto=compress&cs=tinysrgb&w=800', 
                'adat/tradisional'  => 'https://images.pexels.com/photos/30700704/pexels-photo-30700704.jpeg', 
                'pesta'             => 'https://images.pexels.com/photos/30131213/pexels-photo-30131213.jpeg',
                'kasual'            => 'https://images.unsplash.com/photo-1525507119028-ed4c629a60a3?auto=format&fit=crop&w=800&q=80',
                'kostum/cosplay'    => 'https://images.unsplash.com/photo-1501432377862-3d0432b87a14?auto=format&fit=crop&w=800&q=80',
                'olahraga'          => 'https://images.unsplash.com/photo-1517836357463-d25dfeac3438?auto=format&fit=crop&w=800&q=80',
            ];
        @endphp

        @foreach($kategoris as $key => $label)
        <div class="col-12 col-sm-6 col-lg-4">
            <a href="{{ route('kategori.show', ['slug' => str_replace('/', '-', $key)]) }}" class="text-decoration-none">
                <div class="card category-card border-0 shadow-lg overflow-hidden">
                    <div class="img-container">
                        <img src="{{ $kategoriImages[$key] ?? 'https://via.placeholder.com/800x1200?text=Gambar+Tidak+Tersedia' }}" 
                             class="category-img" 
                             alt="{{ $label }}">
                        
                        {{-- Overlay Warna Saat Hover --}}
                        <div class="hover-overlay"></div>

                        <div class="category-info text-center w-100">
                            <h4 class="m-0 fw-bold text-white mb-2" style="letter-spacing: 1px;">{{ strtoupper($label) }}</h4>
                            <div class="view-label-custom">
                                Lihat Koleksi <i class="fas fa-arrow-right ms-2"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </div>
        @endforeach
    </div>
</div>

<style>
    /* Tombol Kembali Custom (Sinkron dengan Sidebar) */
    .btn-back-custom {
        background: linear-gradient(90deg, #FF8C00, #FF4500);
        color: white;
        border: none;
        transition: all 0.3s ease;
    }
    .btn-back-custom:hover {
        background: #333;
        color: white;
        transform: translateX(-5px);
    }

    /* Container Gambar */
    .img-container {
        position: relative;
        width: 100%;
        height: 480px;
        overflow: hidden;
        border-radius: 20px;
    }

    .category-img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        object-position: center top;
        transition: transform 1s cubic-bezier(0.25, 1, 0.5, 1);
    }

    /* Overlay Hitam agar Teks Terbaca */
    .category-info {
        position: absolute;
        bottom: 0;
        left: 0;
        padding: 50px 20px 30px;
        background: linear-gradient(to top, rgba(0,0,0,0.8) 0%, rgba(0,0,0,0.2) 60%, transparent 100%);
        z-index: 2;
    }

    /* Overlay Warna Orange saat Hover */
    .hover-overlay {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: linear-gradient(135deg, rgba(255,140,0,0.4), rgba(255,69,0,0.4));
        opacity: 0;
        transition: all 0.4s ease;
        z-index: 1;
    }

    .view-label-custom {
        display: inline-block;
        font-size: 0.8rem;
        font-weight: bold;
        text-transform: uppercase;
        color: #FF8C00;
        background: white;
        padding: 8px 20px;
        border-radius: 50px;
        opacity: 0;
        transform: translateY(20px);
        transition: all 0.4s ease;
    }

    /* Card Hover Effects */
    .category-card:hover .category-img {
        transform: scale(1.15);
    }

    .category-card:hover .hover-overlay {
        opacity: 1;
    }

    .category-card:hover .view-label-custom {
        opacity: 1;
        transform: translateY(0);
    }

    .category-card {
        border-radius: 20px;
        transition: all 0.4s ease;
    }

    .category-card:hover {
        transform: translateY(-15px);
        box-shadow: 0 20px 40px rgba(255, 69, 0, 0.2) !important;
    }

    @import url('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css');
</style>
@endsection