@extends('layout.pelanggan')

@section('content')
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<div class="container my-5">
    <div class="card border-0 shadow-sm rounded-4 mb-4">
        <div class="card-body p-4 d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center">
                <div class="bg-primary rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 60px; height: 60px;">
                    <i class="fas fa-box text-white fa-lg"></i>
                </div>
                <div>
                    <h4 class="fw-bold mb-0">Pengembalian Produk</h4>
                    <p class="text-muted mb-0 small">Daftar produk yang wajib dikembalikan.</p>
                </div>
            </div>
            <span class="badge rounded-pill border border-primary text-primary px-3 py-2">
                Aktif: {{ $penyewaan->count() }} Produk
            </span>
        </div>
    </div>

    @if(session('success'))
        <div class="alert alert-success border-0 shadow-sm mb-4">{{ session('success') }}</div>
    @endif
    @if(session('error'))
        <div class="alert alert-danger border-0 shadow-sm mb-4">{{ session('error') }}</div>
    @endif

    <div class="row">
        @forelse($penyewaan as $item)
        <div class="col-12 mb-3">
            <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
                <div class="card-body p-4">
                    <div class="row align-items-center">
                        <div class="col-md-2 text-center text-md-start">
                            <img src="{{ $item->pakaian->foto ? asset('storage/'.$item->pakaian->foto) : 'https://placehold.co/100x100' }}" 
                                 class="img-fluid rounded-3" style="height: 100px; width: 100px; object-fit: cover;">
                        </div>
                        <div class="col-md-5 mt-3 mt-md-0">
                            <h5 class="fw-bold mb-1">{{ $item->pakaian->nama_pakaian }}</h5>
                            <p class="text-muted small mb-0">ID Sewa: #{{ $item->id }}</p>
                            <p class="text-danger small fw-bold mb-0">Batas Kembali: {{ \Carbon\Carbon::parse($item->tgl_selesai)->format('d M Y') }}</p>
                        </div>
                        <div class="col-md-5 text-md-end mt-3 mt-md-0">
                            <button type="button" class="btn btn-danger rounded-pill px-4 fw-bold shadow-sm" data-bs-toggle="modal" data-bs-target="#modalKembali{{ $item->id }}">
                                <i class="fas fa-shipping-fast me-2"></i>Kembalikan Sekarang
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="modalKembali{{ $item->id }}" tabindex="-1" aria-labelledby="label{{ $item->id }}" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content border-0 shadow rounded-4">
                    <form action="{{ route('pengembalian.store') }}" method="POST">
                        @csrf
                        <input type="hidden" name="transaksi_id" value="{{ $item->id }}">
                        
                        <div class="modal-header border-0 p-4 pb-0">
                            <h5 class="fw-bold" id="label{{ $item->id }}">Konfirmasi Pengembalian</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        
                        <div class="modal-body p-4">
                            <div class="mb-3">
                                <label class="form-label small fw-bold text-uppercase">Kurir Pengiriman</label>
                                <select name="kurir" class="form-select border-2" required onchange="handleKurir({{ $item->id }}, this.value)">
                                    <option value="" disabled selected>-- Pilih Kurir --</option>
                                    <option value="JNE">JNE Express</option>
                                    <option value="J&T">J&T Express</option>
                                    <option value="Antar Sendiri">Antar Langsung ke Toko</option>
                                </select>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label small fw-bold text-uppercase">Nomor Resi / Bukti</label>
                                <input type="text" name="nomor_resi" id="inputResi{{ $item->id }}" class="form-control border-2" placeholder="Masukkan nomor resi" required>
                            </div>
                            
                            <div class="mb-0">
                                <label class="form-label small fw-bold text-uppercase">Kondisi Barang</label>
                                <select name="kondisi" class="form-select border-2">
                                    <option value="Baik">Sangat Baik / Bersih</option>
                                    <option value="Rusak Ringan">Ada Noda / Rusak Ringan</option>
                                    <option value="Rusak Berat">Rusak Berat / Robek</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="modal-footer border-0 p-4 pt-0">
                            <button type="submit" class="btn btn-primary w-100 rounded-pill fw-bold py-2 shadow-sm">KIRIM INFORMASI</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        @empty
        <div class="col-12 text-center py-5">
            <div class="opacity-50 mb-3">
                <i class="fas fa-box-open fa-4x text-muted"></i>
            </div>
            <p class="text-muted">Tidak ada produk yang perlu dikembalikan saat ini.</p>
            <a href="{{ route('riwayat.index') }}" class="btn btn-outline-primary rounded-pill px-4">Lihat Riwayat Sewa</a>
        </div>
        @endforelse
    </div>
</div>

<script>
    function handleKurir(id, val) {
        const resi = document.getElementById('inputResi' + id);
        if (val === 'Antar Sendiri') {
            resi.value = "DIANTAR_LANGSUNG";
            resi.readOnly = true;
            resi.style.backgroundColor = "#f8f9fa";
        } else {
            resi.value = "";
            resi.readOnly = false;
            resi.style.backgroundColor = "#ffffff";
        }
    }
</script>

<style>
    .rounded-4 { border-radius: 1rem !important; }
    .form-select, .form-control { padding: 0.7rem; border-color: #ebedef; }
    .form-select:focus, .form-control:focus { border-color: #0d6efd; box-shadow: none; }
    .modal-content { overflow: hidden; }
</style>
@endsection