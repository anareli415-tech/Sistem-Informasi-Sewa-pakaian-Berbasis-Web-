<div class="sidebar d-flex flex-column p-3 text-white shadow-lg" 
     style="width: 280px; min-height: 100vh; position: sticky; top: 0; 
            background: linear-gradient(180deg, #121921 0%, #000000 100%); border-right: 1px solid rgba(255,255,255,0.05);">
    
    <div class="d-flex align-items-center mb-4 mt-2 px-2">
        <div class="rounded-3 bg-orange-gradient p-2 me-2 shadow-sm">
            <i class="fa fa-tshirt text-white fs-4"></i>
        </div>
        <h4 class="fw-bold mb-0 text-orange-gradient" style="letter-spacing: 1px;">RFA Store</h4>
    </div>

    <div class="profile-section mb-4 p-3 rounded-4" 
         style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); position: relative; overflow: hidden;">
        
        <div class="text-center">
            {{-- Foto/Inisial --}}
            <div class="position-relative d-inline-block">
                @if(auth()->user()->foto)
                    {{-- Tampil Foto Jika Ada --}}
                    <img src="{{ asset('storage/profile/'.auth()->user()->foto) }}" 
                         class="rounded-circle shadow" 
                         style="width: 65px; height: 65px; border: 3px solid rgba(255,255,255,0.1); object-fit: cover;">
                @else
                    {{-- Tampil Inisial Jika Foto Kosong --}}
                    <div class="rounded-circle bg-orange-gradient d-flex align-items-center justify-content-center shadow" 
                         style="width: 65px; height: 65px; border: 3px solid rgba(255,255,255,0.1); font-size: 1.5rem; font-weight: bold;">
                        {{ strtoupper(substr(auth()->user()->name, 0, 1)) }}
                    </div>
                @endif

                {{-- Status Online Indicator --}}
                <span class="position-absolute bottom-0 end-0 bg-success border border-2 border-dark rounded-circle" 
                      style="width: 15px; height: 15px;" title="Online"></span>
            </div>
            
            <h6 class="mt-3 mb-0 fw-bold text-white">{{ auth()->user()->name }}</h6>
            <div class="d-flex align-items-center justify-content-center mt-1">
                <span class="badge bg-soft-orange text-orange px-3 py-1" style="font-size: 0.65rem; border-radius: 50px;">
                    <i class="fas fa-check-circle me-1"></i> PENYEDIA AKTIF
                </span>
            </div>
        </div>
    </div>

    <ul class="nav nav-pills flex-column mb-auto gap-1">
        <li class="nav-item">
            <a href="{{ route('dashboard') }}" class="nav-link {{ request()->routeIs('dashboard') ? 'nav-active' : 'text-white-50' }} rounded-3 py-2 px-3">
                <i class="fa fa-tachometer-alt me-3 text-center" style="width: 20px;"></i> Dashboard
            </a>
        </li>
        <li class="nav-item">
            <a href="{{ route('pakaian.index') }}" class="nav-link {{ request()->routeIs('pakaian.*') ? 'nav-active' : 'text-white-50' }} rounded-3 py-2 px-3">
                <i class="fa fa-boxes me-3 text-center" style="width: 20px;"></i> Kelola Pakaian
            </a>
        </li>
        <li class="nav-item">
            <a href="{{ route('laporan.index') }}" class="nav-link {{ request()->routeIs('laporan.index') ? 'nav-active' : 'text-white-50' }} rounded-3 py-2 px-3">
                <i class="fa fa-chart-line me-3 text-center" style="width: 20px;"></i> Laporan Keuangan
            </a>
        </li>
    </ul>

    <div class="mt-4">
        <div class="p-3 rounded-4 mb-3" style="background: rgba(255,255,255,0.03); border: 1px dashed rgba(255,255,255,0.1);">
            <div class="d-flex justify-content-between align-items-center mb-1">
                <small class="text-white-50" style="font-size: 0.7rem;">System Status</small>
                <small class="text-success fw-bold" style="font-size: 0.7rem;">Stable</small>
            </div>
            <div class="progress" style="height: 4px; background: rgba(255,255,255,0.05);">
                <div class="progress-bar bg-success" style="width: 100%"></div>
            </div>
        </div>

        <form action="{{ route('logout') }}" method="POST">
            @csrf
            <button type="submit" class="btn btn-logout-penyedia w-100 rounded-pill py-2 fw-bold">
                <i class="fa fa-power-off me-2"></i> Keluar Sistem
            </button>
        </form>
    </div>
</div>

<style>
    .text-orange-gradient {
        background: linear-gradient(90deg, #FF8C00, #FF4500);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
    }
    .bg-orange-gradient { 
        background: linear-gradient(135deg, #FF8C00 0%, #FF4500 100%); 
    }
    .text-orange { color: #FF8C00 !important; }
    .bg-soft-orange { background: rgba(255, 140, 0, 0.12); }

    .sidebar .nav-link {
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        font-size: 0.9rem;
        display: flex;
        align-items: center;
    }

    .nav-active { 
        background: linear-gradient(90deg, #FF8C00, #FF4500) !important; 
        color: white !important; 
        font-weight: 600;
        box-shadow: 0 4px 15px rgba(255, 69, 0, 0.3);
    }

    .sidebar .nav-link:hover:not(.nav-active) { 
        background: rgba(255,255,255,0.05); 
        color: white !important; 
        transform: translateX(5px);
    }

    .btn-logout-penyedia {
        background: rgba(255, 77, 77, 0.05);
        color: #ff4d4d;
        border: 1px solid rgba(255, 77, 77, 0.2);
        transition: all 0.3s ease;
        font-size: 0.85rem;
    }

    .btn-logout-penyedia:hover {
        background: #ff4d4d;
        color: white;
        box-shadow: 0 8px 20px rgba(255, 77, 77, 0.25);
    }
</style>