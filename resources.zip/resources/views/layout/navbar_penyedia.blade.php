<nav class="navbar navbar-expand bg-light navbar-light shadow-sm mb-4">
    <div class="container position-relative d-flex align-items-center">

        <!-- Search di tengah -->
        <form class="position-absolute start-50 translate-middle-x d-flex w-50" action="{{ route('pakaian.index') }}" method="GET">
            <input class="form-control me-2" type="search" name="search" placeholder="Cari Pakaian..." aria-label="Search">
            <button class="btn btn-primary" type="submit"><i class="fa fa-search"></i></button>
        </form>

        <!-- Kanan: Halo User -->
        <div class="ms-auto">
            <span class="fw-semibold">Halo, {{ auth()->user()->name }}</span>
        </div>
    </div>
</nav>
