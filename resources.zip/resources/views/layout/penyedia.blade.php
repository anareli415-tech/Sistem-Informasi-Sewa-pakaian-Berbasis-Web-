<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>@yield('title', 'RFA Store Penyedia')</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="{{ asset('assets/css/bootstrap.min.css')}}" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body { background-color: #f4f7fa; font-family: 'Plus Jakarta Sans', sans-serif; }
    </style>
</head>
<body>
    <div class="d-flex min-vh-100">
        @include('layout.sidebar_penyedia')
        <div class="flex-grow-1">
            @include('layout.navbar_penyedia')
            <main class="p-4">
                @yield('content')
            </main>
        </div>
    </div>
    <script src="{{ asset('assets/js/bootstrap.bundle.min.js') }}"></script>
</body>
</html>