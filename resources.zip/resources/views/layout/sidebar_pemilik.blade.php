<div class="sidebar position-fixed top-0 start-0 bottom-0 bg-navy shadow" style="width: 260px; z-index: 1000; transition: all 0.3s;">
    <div class="sidebar-header p-4 d-flex align-items-center justify-content-center border-bottom border-secondary">
        <div class="logo-icon bg-warning rounded-3 p-2 me-2">
            <i class="fa fa-crown text-navy"></i>
        </div>
        <h4 class="fw-bold text-white mb-0 tracking-wider">RFA Store</h4>
    </div>

    <div class="profile-section px-4 py-4 text-center">
        <div class="avatar-container mb-3">
            <img src="https://ui-avatars.com/api/?name={{ urlencode(auth()->user()->name) }}&background=FF8C00&color=fff" 
                 class="rounded-circle border border-3 border-warning shadow-sm" width="70" alt="Admin">
        </div>
        <h6 class="text-white fw-bold mb-0">{{ auth()->user()->name }}</h6>
        <small class="text-warning text-uppercase ls-1">Administrator</small>
    </div>

    <div class="sidebar-menu px-3">
        <small class="text-uppercase text-secondary fw-bold px-3 mb-2 d-block" style="font-size: 0.7rem;">Main Menu</small>
        
        <ul class="nav flex-column gap-1">
            <li class="nav-item">
                <a href="{{ route('dashboard.pemilik') }}" class="nav-link {{ request()->routeIs('dashboard.pemilik') ? 'active' : '' }}">
                    <i class="fa fa-th-large me-3"></i> Dashboard
                </a>
            </li>

           <li class="nav-item">
    <a href="{{ route('users.index') }}" class="nav-link {{ request()->routeIs('users.index') ? 'active' : '' }}">
        <i class="fa fa-users me-3"></i> Manajemen User
    </a>
</li>

        <li class="nav-item">
    <a href="{{ route('toko.daftar') }}" class="nav-link {{ request()->routeIs('toko.daftar') ? 'active' : '' }}">
        <i class="fa fa-boxes me-3"></i> Direktori Toko
    </a>
</li>

            <small class="text-uppercase text-secondary fw-bold px-3 mt-4 mb-2 d-block" style="font-size: 0.7rem;">Monitoring</small>

           <a href="{{ route('pemilik.laporan_omset') }}" class="nav-link {{ request()->routeIs('pemilik.laporan_omset') ? 'active' : '' }}">
    <i class="fa fa-chart-bar me-3"></i> Omset Platform
</a>


            <li class="nav-item mt-5">
                <form action="{{ route('logout') }}" method="POST" class="d-inline">
                    @csrf
                    <button type="submit" class="nav-link text-danger border-0 bg-transparent w-100 text-start">
                        <i class="fa fa-sign-out-alt me-3"></i> Keluar System
                    </button>
                </form>
            </li>
        </ul>
    </div>
</div>

<style>
    /* Custom Styling for Owner Sidebar */
    .bg-navy {
        background: #1a2a6c; /* Warna Biru Navy Gelap */
        background: linear-gradient(180deg, #1a2a6c 0%, #0a1128 100%);
    }

    .ls-1 { letter-spacing: 1px; }

    .nav-link {
        color: rgba(255, 255, 255, 0.7);
        padding: 12px 20px;
        border-radius: 12px;
        font-weight: 500;
        transition: all 0.3s ease;
        display: flex;
        align-items: center;
    }

    .nav-link i {
        font-size: 1.1rem;
        width: 25px;
        text-align: center;
    }

    .nav-link:hover {
        background: rgba(255, 255, 255, 0.1);
        color: #fff;
        transform: translateX(5px);
    }

    .nav-link.active {
        background: #FF8C00; /* Warna Orange sebagai aksen */
        color: #fff;
        box-shadow: 0 4px 15px rgba(255, 140, 0, 0.3);
    }

    .nav-link.active:hover {
        transform: none;
        background: #e67e00;
    }

    /* Scrollbar Styling */
    .sidebar::-webkit-scrollbar {
        width: 4px;
    }
    .sidebar::-webkit-scrollbar-thumb {
        background: rgba(255, 255, 255, 0.2);
    }
</style>