<div class="sidebar d-flex flex-column p-3 text-white shadow-lg" 
     style="width: 280px; min-height: 100vh; position: sticky; top: 0; 
            background: linear-gradient(180deg, #FF8C00 0%, #FF4500 100%);">
    
    <div class="profile-card mb-4 mt-2 p-3 rounded-4" 
         style="background: rgba(255, 255, 255, 0.2); backdrop-filter: blur(10px); border: 1px solid rgba(255, 255, 255, 0.3);">
        <div class="d-flex align-items-center">
            {{-- Avatar Inisial --}}
            <div class="rounded-circle bg-white d-flex align-items-center justify-content-center shadow-sm" 
                 style="width: 55px; height: 55px; min-width: 55px; font-weight: bold; font-size: 1.3rem; color: #FF4500; border: 2px solid rgba(255, 255, 255, 0.5);">
                {{ strtoupper(substr(auth()->user()->name, 0, 1)) }}
            </div>
            {{-- Nama & Role --}}
            <div class="ms-3 overflow-hidden">
                <h6 class="mb-0 fw-bold text-truncate" style="text-shadow: 1px 1px 2px rgba(0,0,0,0.1);">
                    {{ auth()->user()->name }}
                </h6>
                <small class="badge rounded-pill bg-white text-dark mt-1 text-uppercase fw-bold" style="font-size: 0.6rem; letter-spacing: 0.5px;">
                    {{ auth()->user()->role ?? 'Pelanggan' }}
                </small>
            </div>
        </div>
    </div>

    <ul class="nav nav-pills flex-column mb-auto">
        <li class="nav-item mb-2">
            <a href="{{ route('dashboard') }}" class="nav-link {{ request()->is('dashboard*') ? 'nav-active' : 'text-white' }} rounded-3 py-2 px-3">
                <i class="fas fa-house me-3 text-center" style="width: 20px;"></i> Dashboard
            </a>
        </li>
        <li class="nav-item mb-2">
            <a href="{{ route('kategori.index') }}" class="nav-link {{ request()->is('kategori*') ? 'nav-active' : 'text-white' }} rounded-3 py-2 px-3">
                <i class="fas fa-tags me-3 text-center" style="width: 20px;"></i> Kategori Pakaian
            </a>
        </li>
        <li class="nav-item mb-2">
            <a href="{{ route('riwayat.index') }}" class="nav-link {{ request()->is('riwayat*') ? 'nav-active' : 'text-white' }} rounded-3 py-2 px-3">
                <i class="fas fa-clock-rotate-left me-3 text-center" style="width: 20px;"></i> Riwayat Sewa
            </a>
        </li>
        
        {{-- FITUR BARU: PENGEMBALIAN --}}
        <li class="nav-item mb-2">
            <a href="{{ route('pengembalian.index') }}" class="nav-link {{ request()->is('pengembalian*') ? 'nav-active' : 'text-white' }} rounded-3 py-2 px-3">
                <i class="fas fa-box-open me-3 text-center" style="width: 20px;"></i> Pengembalian
            </a>
        </li>
    </ul>

    <hr class="my-4" style="background-color: rgba(255,255,255,0.3); opacity: 1;">

    <form action="{{ route('logout') }}" method="POST" class="mt-auto">
        @csrf
        <button type="submit" class="btn btn-logout w-100 rounded-pill py-2 fw-bold shadow">
            <i class="fas fa-sign-out-alt me-2"></i> Keluar
        </button>
    </form>
</div>

<style>
    /* Link Navigasi */
    .sidebar .nav-link {
        transition: all 0.3s ease;
        opacity: 0.85;
    }

    .sidebar .nav-link:hover {
        background: rgba(255, 255, 255, 0.15);
        opacity: 1;
        transform: translateX(5px);
        color: white;
    }

    /* Keadaan Aktif */
    .nav-active {
        background-color: white !important;
        color: #FF4500 !important;
        font-weight: bold;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
    }

    /* Tombol Logout Custom */
    .btn-logout {
        background-color: rgba(255, 255, 255, 0.2);
        color: white;
        border: 1px solid rgba(255, 255, 255, 0.4);
        backdrop-filter: blur(5px);
    }

    .btn-logout:hover {
        background-color: #dc3545;
        color: white;
        border-color: #dc3545;
    }
</style>