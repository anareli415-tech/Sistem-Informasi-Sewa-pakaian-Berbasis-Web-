<!-- Sidebar Start -->
<div class="sidebar pe-4 pb-3" style="background: linear-gradient(to bottom, #a5d6a7, #e8f5e9);">
    <nav class="navbar navbar-light">
        <!-- Brand -->
        <a href="{{ route('dashboard') }}" class="navbar-brand mx-4 mb-3 d-flex align-items-center">
            <img src="{{ asset('assets/img/leaf.jpg') }}" alt="Logo" style="width: 30px; height: 30px;" class="me-2">
            <h4 class="text-success mb-0 fw-bold">RFA Store</h4>
        </a>

        <!-- User Info -->
        <div class="d-flex align-items-center ms-4 mb-4">
            <div class="position-relative">
                <img class="rounded-circle shadow" src="{{ asset('assets/img/userrjpg.jpg') }}" alt="User" style="width: 45px; height: 45px; object-fit: cover;">
                <div class="bg-success rounded-circle border border-2 border-white position-absolute end-0 bottom-0 p-1"></div>
            </div>
            <div class="ms-3">
                <h6 class="mb-0 text-success fw-semibold">{{ auth()->user()->name }}</h6>
                <span class="text-muted small">{{ auth()->user()->role }}</span>
            </div>
        </div>

        <!-- Menu -->
        <div class="navbar-nav w-100">
            @if(auth()->user()->role === 'pemilik')
                <a href="{{ route('dashboard') }}" class="nav-item nav-link">Dashboard</a>
                <a href="#" class="nav-item nav-link">Data User</a>
                <a href="#" class="nav-item nav-link">Katalog Pakaian</a>
                <a href="#" class="nav-item nav-link">Transaksi</a>
                <a href="#" class="nav-item nav-link">Laporan</a>
            @elseif(auth()->user()->role === 'penyedia')
                <a href="{{ route('dashboard') }}" class="nav-item nav-link">Dashboard</a>
                <a href="#" class="nav-item nav-link">Tambah Pakaian</a>
                <a href="#" class="nav-item nav-link">Kelola Pakaian</a>
                <a href="#" class="nav-item nav-link">Transaksi Tokomu</a>
            @else
                <a href="{{ route('dashboard') }}" class="nav-item nav-link">Dashboard</a>
                <a href="#" class="nav-item nav-link">Katalog Pakaian</a>
                <a href="#" class="nav-item nav-link">Riwayat Sewa</a>
            @endif
        </div>
    </nav>
</div>
<!-- Sidebar End -->
