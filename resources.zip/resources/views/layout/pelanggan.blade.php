<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>@yield('title', 'RFA Store Pelanggan')</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link href="{{ asset('assets/css/bootstrap.min.css')}}" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">

    <style>
        body { background-color: #f8f9fa; font-family: 'Inter', sans-serif; }
        
        /* Animasi Card Umum */
        .card-dashboard, .card {
            transition: transform 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275), box-shadow 0.3s ease;
            border: none;
        }

        .card-dashboard:hover, .card:hover {
            transform: translateY(-8px);
            box-shadow: 0 15px 30px rgba(0,0,0,0.1);
        }

        /* Scrollbar kustom untuk Sidebar */
        ::-webkit-scrollbar { width: 5px; }
        ::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.1); border-radius: 10px; }
    </style>
</head>
<body>
    <div class="d-flex min-vh-100">

        @include('layout.sidebar_pelanggan')

        <div class="flex-grow-1 d-flex flex-column">

            @include('layout.navbar_pelanggan')

            <main class="p-4 flex-grow-1">
                @yield('content')
            </main>
            
            <footer class="p-4 text-center text-muted small">
                &copy; {{ date('Y') }} RFA Store - Solusi Sewa Pakaian Modern
            </footer>
        </div>

    </div>

    <script src="{{ asset('assets/js/bootstrap.bundle.min.js') }}"></script>
</body>
</html>