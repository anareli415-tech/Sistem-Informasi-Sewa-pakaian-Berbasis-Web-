<nav class="navbar navbar-expand bg-white navbar-light shadow-sm mb-4 py-3">
    <div class="container position-relative d-flex align-items-center">

        <a class="navbar-brand fw-bold text-orange-gradient" href="{{ route('dashboard') }}">
            RFA Store
        </a>

        <div class="position-absolute start-50 translate-middle-x w-50">
            <form action="{{ route('kategori.index') }}" method="GET">
                <div class="search-wrapper">
                    <i class="fa fa-search text-muted ms-3"></i>
                    <input class="search-input" 
                           type="search" name="search" value="{{ request('search') }}" 
                           placeholder="Cari Jas, Kebaya, atau lainnya..." 
                           autocomplete="off">
                    <button class="btn-search-action" type="submit">
                        Cari
                    </button>
                </div>
            </form>
        </div>

        <div class="ms-auto d-flex align-items-center">
            <div class="user-profile-nav d-flex align-items-center">
                <div class="text-end me-2 d-none d-md-block">
                    <small class="text-muted d-block">Selamat Datang,</small>
                    <span class="fw-bold text-dark">{{ auth()->user()->name }}</span>
                </div>
                <div class="avatar-circle">
                    {{ strtoupper(substr(auth()->user()->name, 0, 1)) }}
                </div>
            </div>
        </div>
    </div>
</nav>

<style>
    /* Gradient Text untuk Brand */
    .text-orange-gradient {
        background: linear-gradient(45deg, #ff8c00, #ff5e00);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
    }

    /* Wrapper Search Bar */
    .search-wrapper {
        display: flex;
        align-items: center;
        background: #f8f9fa;
        border: 1px solid #e9ecef;
        border-radius: 50px;
        padding: 4px;
        transition: all 0.3s ease;
    }

    .search-wrapper:focus-within {
        background: #ffffff;
        border-color: #ff8c00;
        box-shadow: 0 4px 12px rgba(255, 140, 0, 0.1);
    }

    /* Input Field */
    .search-input {
        flex: 1;
        border: none;
        background: transparent;
        padding: 8px 15px;
        outline: none;
        font-size: 0.9rem;
        color: #495057;
    }

    /* Tombol Cari di dalam Input */
    .btn-search-action {
        background: linear-gradient(45deg, #ff8c00, #ff5e00);
        color: white;
        border: none;
        padding: 7px 20px;
        border-radius: 50px;
        font-weight: 600;
        font-size: 0.85rem;
        transition: all 0.3s ease;
    }

    .btn-search-action:hover {
        transform: scale(1.05);
        box-shadow: 0 3px 10px rgba(255, 94, 0, 0.2);
    }

    /* Avatar Circle Kanan */
    .avatar-circle {
        width: 40px;
        height: 40px;
        background: #fff3e0;
        color: #ff8c00;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: bold;
        border: 2px solid #ffe0b2;
    }

    .user-profile-nav {
        padding: 5px 12px;
        border-radius: 50px;
        transition: background 0.3s;
        cursor: pointer;
    }

    .user-profile-nav:hover {
        background: #f8f9fa;
    }
</style>