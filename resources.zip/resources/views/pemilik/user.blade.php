@extends('layout.app')

@section('title', 'Daftar Pengguna Platform')

@section('content')
@include('layout.sidebar_pemilik')

<div class="main-content-wrapper" style="margin-left: 260px; padding: 30px; background: #f4f7f6; min-height: 100vh;">
    <div class="container-fluid">
        <div class="row mb-4">
            <div class="col-md-12 text-navy">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h3 class="fw-bold mb-1"><i class="fa fa-users-cog me-2"></i> Manajemen Pengguna</h3>
                        <p class="text-muted">Data otomatis tersinkronisasi dengan pendaftaran sistem.</p>
                    </div>
                    <div class="text-end">
                        <span class="badge bg-navy px-4 py-2 rounded-pill shadow-sm">
                            Total User: {{ $users->total() }}
                        </span>
                    </div>
                </div>
            </div>
        </div>

        <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light">
                        <tr class="text-uppercase text-secondary" style="font-size: 0.8rem; letter-spacing: 1px;">
                            <th class="ps-4 py-3">User & Email</th>
                            <th class="py-3">Role</th>
                            <th class="py-3">Nama Toko</th>
                            <th class="py-3">Status Registrasi</th>
                            <th class="text-center py-3">Aksi</th>
                        </tr>
                    </thead>
                    <tbody style="border-top: 0;">
                        @foreach($users as $user)
                        <tr>
                            <td class="ps-4">
                                <div class="d-flex align-items-center">
                                    <div class="avatar-sm bg-primary text-white rounded-circle d-flex align-items-center justify-content-center fw-bold me-3" style="width: 38px; height: 38px;">
                                        {{ substr($user->name, 0, 1) }}
                                    </div>
                                    <div>
                                        <div class="fw-bold text-dark">{{ $user->name }}</div>
                                        <small class="text-muted">{{ $user->email }}</small>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <span class="badge {{ $user->role == 'penyedia' ? 'bg-warning-light text-warning' : 'bg-info-light text-info' }} px-3 py-2 rounded-pill" style="font-size: 0.7rem;">
                                    <i class="fa {{ $user->role == 'penyedia' ? 'fa-store' : 'fa-user' }} me-1"></i>
                                    {{ strtoupper($user->role) }}
                                </span>
                            </td>
                            <td>
                                @if($user->role == 'penyedia')
                                    <span class="fw-bold text-navy">{{ $user->toko->nama_toko ?? 'N/A' }}</span>
                                @else
                                    <span class="text-muted small italic">N/A (Pelanggan)</span>
                                @endif
                            </td>
                            <td>
<small class="text-muted">
    <i class="fa fa-calendar-alt me-1"></i>
    {{ optional($user->created_at)->format('d M Y') ?? '-' }}
</small>

                            </td>
                            <td class="text-center pe-4">
                                <form action="{{ route('users.destroy', $user->id) }}" method="POST" onsubmit="return confirm('Hapus user ini selamanya?')">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-sm btn-outline-danger border-0 rounded-circle p-2">
                                        <i class="fa fa-trash-alt"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

            <div class="card-footer bg-white border-0 p-4">
                {{ $users->links() }}
            </div>
        </div>
    </div>
</div>

<style>
    .text-navy { color: #1a2a6c; }
    .bg-navy { background: #1a2a6c; }
    .bg-warning-light { background: #fff8e6; }
    .bg-info-light { background: #e7faff; }
    .table-hover tbody tr:hover { background-color: #f8f9ff; }
</style>
@endsection