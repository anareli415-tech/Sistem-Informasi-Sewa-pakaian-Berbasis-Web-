@extends('layout.app')

@section('title', 'Laporan Omset Platform')

@section('content')
@include('layout.sidebar_pemilik')

<div class="main-content-wrapper" style="margin-left: 260px; padding: 30px; background: #f4f7f6; min-height: 100vh;">
    <div class="container-fluid">
        
        <div class="d-flex justify-content-between align-items-center mb-4 d-print-none">
            <h3 class="fw-bold text-navy mb-0">Laporan Omset & PPN Platform</h3>
            <button onclick="window.print()" class="btn btn-navy rounded-pill px-4 shadow-sm">
                <i class="fa fa-print me-2"></i> Cetak Laporan
            </button>
        </div>

        <div class="d-none d-print-block text-center mb-4">
            <h2 class="fw-bold">RENT STYLE - LAPORAN OMSET</h2>
            <p>Periode: {{ $tglMulai ?? 'Awal' }} s/d {{ $tglSelesai ?? 'Sekarang' }}</p>
            <hr>
        </div>

        <div class="card border-0 shadow-sm rounded-4 p-4 mb-4 d-print-none">
    <form action="{{ route('pemilik.laporan_omset') }}" method="GET" class="row align-items-end">
        <div class="col-md-4">
            <label class="form-label small fw-bold">Tanggal Mulai</label>
            <input type="date" name="tgl_mulai" class="form-control rounded-pill" value="{{ $tglMulai }}">
        </div>
        <div class="col-md-4">
            <label class="form-label small fw-bold">Tanggal Selesai</label>
            <input type="date" name="tgl_selesai" class="form-control rounded-pill" value="{{ $tglSelesai }}">
        </div>
        <div class="col-md-4">
            <button type="submit" class="btn btn-primary rounded-pill px-4 me-2">Filter</button>
            <a href="{{ route('pemilik.laporan_omset') }}" class="btn btn-light rounded-pill px-4">Reset</a>
        </div>
    </form>
</div>

        <div class="row mb-4">
            <div class="col-6">
                <div class="card border-0 shadow-sm rounded-4 bg-primary text-white p-4">
                    <small class="opacity-75">Total Omset Bruto (Semua Toko)</small>
                    <h2 class="fw-bold">Rp {{ number_format($totalBruto, 0, ',', '.') }}</h2>
                </div>
            </div>
            <div class="col-6">
                <div class="card border-0 shadow-sm rounded-4 bg-success text-white p-4">
                    <small class="opacity-75">Pendapatan Bersih Platform (PPN 10%)</small>
                    <h2 class="fw-bold">Rp {{ number_format($pendapatanPlatform, 0, ',', '.') }}</h2>
                </div>
            </div>
        </div>

        <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
            <div class="card-header bg-white py-3">
                <h6 class="mb-0 fw-bold">Rincian Kontribusi Tiap Toko</h6>
            </div>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light">
                        <tr>
                            <th class="ps-4">Nama Toko</th>
                            <th>Omset Bruto</th>
                            <th>PPN (10%)</th>
                            <th>Pendapatan Toko</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($laporanToko as $data)
                        <tr>
                            <td class="ps-4">
                                <div class="fw-bold">{{ $data['nama_toko'] }}</div>
                                <small class="text-muted">{{ $data['owner'] }}</small>
                            </td>
                            <td class="text-primary fw-bold">Rp {{ number_format($data['omset_bruto'], 0, ',', '.') }}</td>
                            <td class="text-danger">Rp {{ number_format($data['ppn_platform'], 0, ',', '.') }}</td>
                            <td class="text-success fw-bold">Rp {{ number_format($data['netto_toko'], 0, ',', '.') }}</td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="4" class="text-center py-4 text-muted">Tidak ada data transaksi pada periode ini.</td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<style>
    .btn-navy { background-color: #1a2a6c; color: white; border: none; }
    .btn-navy:hover { background-color: #121d4d; color: white; }
    .text-navy { color: #1a2a6c; }
    .bg-primary { background: linear-gradient(45deg, #1a2a6c, #2a48ad) !important; }
    .bg-success { background: linear-gradient(45deg, #134e4a, #10b981) !important; }

    /* CSS Khusus Print */
    @media print {
        .d-print-none { display: none !important; }
        .main-content-wrapper { margin-left: 0 !important; padding: 0 !important; }
        .card { box-shadow: none !important; border: 1px solid #ddd !important; }
        body { background: white !important; }
    }
</style>
@endsection