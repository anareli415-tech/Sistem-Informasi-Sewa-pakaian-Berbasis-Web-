@extends('layout.app')

@section('title', 'Direktori Toko')

@section('content')
@include('layout.sidebar_pemilik')

<div class="main-content-wrapper" style="margin-left: 260px; padding: 30px; background: #f4f7f6; min-height: 100vh;">
    <div class="container-fluid">
        <h3 class="fw-bold text-navy mb-4">Direktori Toko</h3>

        <div class="row">
            @forelse($tokos as $toko)
            <div class="col-md-4 mb-4">
                <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
                    <div class="card-body p-4">
                        <div class="d-flex align-items-center mb-3">
                            <div class="bg-primary-soft text-primary rounded-3 p-3 me-3">
                                <i class="fa fa-store fa-lg"></i>
                            </div>
                            <div>
                                <h5 class="fw-bold mb-0">{{ $toko->nama_toko }}</h5>
                                <small class="text-muted">Owner: {{ $toko->user->name ?? 'N/A' }}</small>
                            </div>
                        </div>
                        
                        <div class="row text-center bg-light rounded-3 py-2 g-0">
                            <div class="col-12">
                                <small class="text-muted d-block">Total Koleksi Pakaian</small>
                                <span class="fw-bold text-dark">{{ $toko->pakaian_count }} Item</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            @empty
            <div class="col-12 text-center py-5">
                <p class="text-muted">Belum ada toko terdaftar.</p>
            </div>
            @endforelse
        </div>
        
        <div class="mt-4">
            {{ $tokos->links() }}
        </div>
    </div>
</div>

<style>
    .bg-primary-soft { background: #eef2ff; }
    .text-navy { color: #1a2a6c; }
</style>
@endsection