@extends('layout.app')

@section('content')
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8 col-lg-6">
            <div class="card border-0 shadow-lg rounded-4 overflow-hidden">
                {{-- HEADER --}}
                <div class="bg-orange-gradient p-4 text-white text-center" style="background: linear-gradient(45deg, #ff8c00, #ff4500);">
                    <h4 class="fw-bold mb-0">Konfirmasi Pembayaran</h4>
                    <p class="small mb-0 opacity-75">Selesaikan pembayaran untuk pesanan Anda</p>
                </div>

                <div class="card-body p-4">
                    {{-- INFO PRODUK --}}
                    <div class="d-flex align-items-center mb-4 p-3 bg-light rounded-4">
                        <div class="flex-shrink-0 me-3">
                            <div class="bg-warning text-white rounded-circle d-flex align-items-center justify-content-center" style="width: 50px; height: 50px;">
                                <i class="fas fa-receipt fa-lg"></i>
                            </div>
                        </div>
                        <div class="flex-grow-1">
                            <h6 class="fw-bold mb-1 text-dark">{{ $transaksi->pakaian->nama_pakaian }}</h6>
                            <span class="badge bg-secondary rounded-pill small">Qty: {{ $transaksi->jumlah ?? 1 }} Unit</span>
                        </div>
                    </div>

                    {{-- RINCIAN BIAYA --}}
                    <div class="mb-4">
                        <h6 class="fw-bold text-dark mb-3">Rincian Biaya</h6>
                        
                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted">Biaya Sewa ({{ $transaksi->lama }} Hari)</span>
                            <span class="fw-bold">Rp {{ number_format($transaksi->total_sewa, 0, ',', '.') }}</span>
                        </div>

                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted">Uang Jaminan (Deposit) 
                                <i class="fas fa-info-circle ms-1" data-bs-toggle="tooltip" title="Akan dikembalikan setelah barang kembali dalam kondisi baik"></i>
                            </span>
                            <span class="fw-bold text-danger">+ Rp {{ number_format($transaksi->total_deposit, 0, ',', '.') }}</span>
                        </div>

                        <hr style="border-top: 2px dashed #bbb;">
                        
                        <div class="d-flex justify-content-between align-items-center mt-3">
                            <span class="h5 fw-bold mb-0">Total Harus Dibayar</span>
                            <span class="h4 fw-bold text-primary mb-0">Rp {{ number_format($transaksi->total_bayar, 0, ',', '.') }}</span>
                        </div>
                        <p class="text-muted small mt-2 fst-italic text-center">
                            *Deposit akan di-refund penuh jika pakaian kembali tanpa kerusakan.
                        </p>
                    </div>

                    {{-- TOMBOL AKSI --}}
                    <div class="d-grid gap-2">
                        {{-- Tombol ini akan mentrigger Snap Midtrans --}}
                        <button id="pay-button" class="btn btn-primary btn-lg rounded-pill fw-bold shadow-sm py-3">
                            <i class="fas fa-shield-alt me-2"></i>Bayar Sekarang
                        </button>
                        <a href="{{ route('dashboard') }}" class="btn btn-link text-muted text-decoration-none small mt-2">
                            Kembali ke Beranda
                        </a>
                    </div>
                </div>

                <div class="card-footer bg-white border-0 text-center pb-4">
                    <div class="d-flex justify-content-center align-items-center gap-3 opacity-50">
                        <i class="fab fa-cc-visa fa-2x"></i>
                        <i class="fab fa-cc-mastercard fa-2x"></i>
                        <i class="fas fa-university fa-2x"></i>
                        <span class="small fw-bold">Secure Gateway</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

{{-- MIDTRANS SNAP JS --}}
<script src="https://app.sandbox.midtrans.com/snap/snap.js" data-client-key="{{ config('midtrans.client_key') }}"></script>
<script type="text/javascript">
    var payButton = document.getElementById('pay-button');
    payButton.addEventListener('click', function () {
        // Trigger Snap popup menggunakan token dari database
        window.snap.pay('{{ $snapToken }}', {
            onSuccess: function(result) {
                alert("Pembayaran Berhasil!");
                // Langsung lempar ke dashboard saja, tidak perlu route pembayaran.sukses
                window.location.href = "{{ route('dashboard') }}";
            },
            onPending: function(result) {
                alert("Menunggu pembayaran Anda!");
                window.location.href = "{{ route('dashboard') }}";
            },
            onError: function(result) {
                alert("Pembayaran gagal!");
            },
            onClose: function() {
                alert('Anda menutup popup tanpa menyelesaikan pembayaran');
            }
        });
    });

    // Tooltip initialization
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
      return new bootstrap.Tooltip(tooltipTriggerEl)
    })
</script>
@endsection