@extends('layout.app')

@section('title', 'Tambah Pakaian')

@section('content')
<style>
    /* Styling untuk checkbox agar terlihat seperti tombol tag */
    .size-checkbox-group input[type="checkbox"] {
        display: none;
    }
    .size-checkbox-group label {
        display: inline-block;
        padding: 8px 20px;
        border: 2px solid #dee2e6;
        border-radius: 10px;
        cursor: pointer;
        font-weight: bold;
        transition: all 0.2s;
        margin-right: 5px;
        margin-bottom: 5px;
        color: #6c757d;
    }
    .size-checkbox-group input[type="checkbox"]:checked + label {
        background-color: #0d6efd;
        border-color: #0d6efd;
        color: white;
    }
</style>

<div class="container mt-4">
    <div class="card shadow border-0 rounded-4">
        <div class="card-header bg-white py-3">
            <h5 class="mb-0 fw-bold">Tambah Pakaian Baru</h5>
        </div>
        <div class="card-body p-4">
            <form action="{{ route('pakaian.store') }}" method="POST" enctype="multipart/form-data">
                @csrf
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-bold">Nama Pakaian</label>
                        <input type="text" class="form-control" name="nama_pakaian" value="{{ old('nama_pakaian') }}" required placeholder="Contoh: Jas Hitam Slimfit">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-bold">Jenis</label>
                        <select class="form-select" name="jenis" required>
                            <option value="">-- Pilih Jenis --</option>
                            <option value="formal">Formal</option>
                            <option value="adat/tradisional">Adat/Tradisional</option>
                            <option value="pesta">Pesta</option>
                            <option value="kasual">Kasual</option>
                            <option value="kostum/cosplay">Kostum/Cosplay</option>
                            <option value="olahraga">Olahraga</option>
                        </select>
                    </div>

                    {{-- SECTION UKURAN DENGAN CHECKBOX --}}
                    <div class="col-12 mb-3">
                        <label class="form-label fw-bold d-block">Pilih Ukuran yang Tersedia</label>
                        <div class="size-checkbox-group">
                            @php $sizes = ['S', 'M', 'L', 'XL', 'XXL', 'All Size']; @endphp
                            @foreach($sizes as $size)
                                <input type="checkbox" name="ukuran[]" value="{{ $size }}" id="check{{ $size }}">
                                <label for="check{{ $size }}">{{ $size }}</label>
                            @endforeach
                        </div>
                        <small class="text-muted">*Anda bisa memilih lebih dari satu ukuran.</small>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-bold">Stok Barang (Total Seluruh Unit)</label>
                        <input type="number" class="form-control" name="stok" value="{{ old('stok') }}" required min="0">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-bold">Foto Pakaian</label>
                        <input type="file" name="foto" class="form-control" required>
                    </div>

                    <hr class="my-3">

                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-bold text-primary">Harga Sewa (Per Hari)</label>
                        <div class="input-group">
                            <span class="input-group-text">Rp</span>
                            <input type="number" class="form-control" name="harga" value="{{ old('harga') }}" required placeholder="0">
                        </div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-bold text-danger">Wajib Deposit (Jaminan)</label>
                        <div class="input-group">
                            <span class="input-group-text">Rp</span>
                            <input type="number" class="form-control" name="deposit" value="{{ old('deposit') }}" required placeholder="0">
                        </div>
                        <small class="text-muted italic">*Uang jaminan akan dikembalikan saat barang kembali.</small>
                    </div>

                    <div class="col-12 mb-4">
                        <label class="form-label fw-bold">Deskripsi Pakaian</label>
                        <textarea class="form-control" name="deskripsi" rows="3" placeholder="Ceritakan kondisi atau kelengkapan pakaian...">{{ old('deskripsi') }}</textarea>
                    </div>
                </div>

                <div class="d-flex justify-content-end gap-2">
                    <a href="{{ route('pakaian.index') }}" class="btn btn-light px-4">Batal</a>
                    <button class="btn btn-primary px-5 fw-bold">Simpan Pakaian</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection