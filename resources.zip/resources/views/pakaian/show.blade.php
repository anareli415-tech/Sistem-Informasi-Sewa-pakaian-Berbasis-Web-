@extends('layout.app')

@section('content')
<style>
    /* Styling Dasar Card */
    .product-card {
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        border-radius: 20px !important;
        overflow: hidden;
    }
    .product-card:hover {
        transform: translateY(-10px);
        box-shadow: 0 15px 30px rgba(0,0,0,0.1) !important;
    }
    .img-wrapper {
        height: 250px;
        overflow: hidden;
        position: relative;
    }
    .product-img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform 0.5s ease;
    }
    .product-card:hover .product-img { transform: scale(1.1); }

    /* MODERN SIZE SELECTOR BUTTONS */
    .size-selector {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
    }
    .size-selector input[type="radio"] {
        display: none; 
    }
    .size-selector label {
        display: flex;
        align-items: center;
        justify-content: center;
        min-width: 50px;
        height: 45px;
        padding: 0 15px;
        border: 2px solid #edeff2;
        border-radius: 12px;
        cursor: pointer;
        font-weight: 700;
        color: #4a5568;
        transition: all 0.2s ease-in-out;
        background: white;
    }
    .size-selector label:hover {
        border-color: #ff8c00;
        color: #ff8c00;
        background: #fff9f2;
    }
    .size-selector input[type="radio"]:checked + label {
        border-color: #ff8c00;
        background-color: #ff8c00;
        color: white;
        box-shadow: 0 4px 10px rgba(255, 140, 0, 0.3);
    }

    .badge-size {
        position: absolute;
        top: 15px;
        right: 15px;
        background: rgba(255, 255, 255, 0.9);
        backdrop-filter: blur(5px);
        color: #ff8c00;
        padding: 5px 15px;
        border-radius: 50px;
        font-weight: bold;
        font-size: 0.75rem;
        z-index: 10;
    }

    .text-orange-gradient {
        background: linear-gradient(45deg, #ff8c00, #ff5e00);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
    }

    .btn-orange-gradient {
        background: linear-gradient(45deg, #ff8c00, #ff5e00);
        color: white;
        border: none;
    }
    .btn-orange-gradient:hover {
        background: linear-gradient(45deg, #ff5e00, #ff8c00);
        color: white;
    }
    
    .description-text {
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
        font-size: 0.85rem;
        color: #6c757d;
        height: 2.6rem;
    }

    /* SALES PROOF POPUP CSS */
    .sales-toast {
        position: fixed;
        bottom: 20px;
        left: -450px; /* Sembunyi */
        z-index: 9999;
        background: white;
        padding: 12px 18px;
        border-radius: 15px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.15);
        display: flex;
        align-items: center;
        gap: 12px;
        transition: all 0.6s cubic-bezier(0.68, -0.55, 0.27, 1.55);
        border-left: 5px solid #ff8c00;
        max-width: 320px;
    }
    .sales-toast.show { left: 20px; }
    .toast-img { width: 50px; height: 50px; border-radius: 10px; object-fit: cover; }
    .toast-content p { margin: 0; font-size: 0.8rem; line-height: 1.2; }
    .toast-time { font-size: 0.7rem; color: #aaa; }
</style>

<div class="container py-5">
    {{-- Header Section --}}
    <div class="d-flex justify-content-between align-items-center mb-5 p-4 bg-white rounded-4 shadow-sm">
        <div>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-2 small">
                    <li class="breadcrumb-item"><a href="{{ route('dashboard') }}" class="text-decoration-none text-muted">Dashboard</a></li>
                    <li class="breadcrumb-item active fw-bold text-warning" aria-current="page">Kategori {{ $kategoriNama }}</li>
                </ol>
            </nav>
            <h2 class="fw-bold text-dark m-0">Koleksi <span class="text-orange-gradient">{{ $kategoriNama }}</span></h2>
        </div>
        <a href="{{ url('/kategori') }}" class="btn btn-outline-warning rounded-pill px-4">
            <i class="fas fa-arrow-left me-2"></i> Kembali
        </a>
    </div>

    {{-- Grid Produk --}}
    <div class="row g-4">
        @forelse($pakaians as $pakaian)
            <div class="col-sm-6 col-md-4 col-lg-3">
                <div class="card h-100 border-0 shadow-sm product-card">
                    <div class="img-wrapper">
                        <img src="{{ asset('storage/' . $pakaian->foto) }}" class="product-img" alt="{{ $pakaian->nama_pakaian }}">
                        <div class="badge-size shadow-sm">Tersedia: {{ $pakaian->ukuran }}</div>
                    </div>

                    <div class="card-body d-flex flex-column p-4">
                        <div class="d-flex align-items-center mb-2">
                            <i class="fas fa-store text-warning me-2" style="font-size: 0.8rem;"></i>
                            <span class="text-muted fw-bold text-uppercase" style="font-size: 0.65rem; letter-spacing: 1px;">
                                {{ $pakaian->user->name ?? 'Toko RFA Store' }}
                            </span>
                        </div>

                        <h6 class="fw-bold mb-1 text-dark text-truncate">{{ $pakaian->nama_pakaian }}</h6>
                        <p class="description-text mb-3">
                            {{ $pakaian->deskripsi ?? 'Pakaian berkualitas tinggi untuk momen spesial Anda.' }}
                        </p>

                        <div class="mb-3">
                            <p class="text-orange-gradient fw-bold mb-0 fs-5">
                                Rp {{ number_format($pakaian->harga,0,',','.') }}
                                <small class="text-muted fw-normal" style="font-size: 0.7rem;">/ hari</small>
                            </p>
                            <small class="text-muted">Deposit: Rp {{ number_format($pakaian->deposit,0,',','.') }}</small>
                        </div>
                        
                        <button type="button" class="btn btn-orange-gradient w-100 rounded-pill mt-auto shadow-sm py-2 fw-bold" 
                                data-bs-toggle="modal" data-bs-target="#rentalModal{{ $pakaian->id }}">
                            Sewa Sekarang
                        </button>
                    </div>
                </div>
            </div>

            {{-- MODAL RENTAL --}}
            <div class="modal fade" id="rentalModal{{ $pakaian->id }}" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-lg">
                    <div class="modal-content border-0 shadow-lg" style="border-radius: 25px;">
                        {{-- FIX ACTION ROUTE --}}
                        <form id="formSewa{{ $pakaian->id }}" action="{{ route('transaksi.store') }}" method="POST">
                            @csrf
                            <input type="hidden" name="pakaian_id" value="{{ $pakaian->id }}">
                            <input type="hidden" class="harga_input" value="{{ $pakaian->harga }}">
                            <input type="hidden" class="deposit_input" value="{{ $pakaian->deposit }}">

                            <div class="modal-header border-0 pb-0 justify-content-center pt-4">
                                <h5 class="fw-bold text-dark">Lengkapi Detail Sewa</h5>
                            </div>
                            
                            <div class="modal-body px-4">
                                <div class="row g-4">
                                    <div class="col-md-6 border-end">
                                        <label class="form-label small fw-bold">Nama Pemesan</label>
                                        <input type="text" class="form-control rounded-pill border-0 bg-light px-3 mb-3" name="nama" value="{{ Auth::user()->name }}" required>
                                        
                                        <label class="form-label small fw-bold">WhatsApp</label>
                                        <input type="text" class="form-control rounded-pill border-0 bg-light px-3 mb-3" name="ponsel" placeholder="08..." required>

                                        <label class="form-label small fw-bold">Alamat Lengkap</label>
                                        <textarea class="form-control rounded-4 border-0 bg-light px-3 mb-3" name="alamat" rows="3" required></textarea>

                                        <div class="p-3 rounded-4 bg-dark text-white shadow-sm mt-2">
                                            <span class="small opacity-75">Total Bayar (Sewa + Deposit)</span>
                                            <h4 class="fw-bold text-warning mb-0 total-display">Rp 0</h4>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="mb-4">
                                            <label class="form-label small fw-bold d-block mb-3"><i class="fas fa-tshirt me-2 text-warning"></i>Pilih Ukuran:</label>
                                            <div class="size-selector">
                                                @php $list_ukuran = explode(',', $pakaian->ukuran); @endphp
                                                @foreach($list_ukuran as $uk)
                                                    @php $trimmedUk = trim($uk); @endphp
                                                    <input type="radio" id="size{{ $trimmedUk }}{{ $pakaian->id }}" name="ukuran_sewa" value="{{ $trimmedUk }}" required>
                                                    <label for="size{{ $trimmedUk }}{{ $pakaian->id }}">{{ $trimmedUk }}</label>
                                                @endforeach
                                            </div>
                                        </div>

                                        <div class="row g-2">
                                            <div class="col-6 mb-3">
                                                <label class="form-label small fw-bold">Tgl Mulai</label>
                                                <input type="date" class="form-control rounded-pill border-0 bg-light tgl_mulai" name="tgl_mulai" required>
                                            </div>
                                            <div class="col-6 mb-3">
                                                <label class="form-label small fw-bold">Lama (Hari)</label>
                                                <input type="number" class="form-control rounded-pill border-0 bg-light lama" name="lama" min="1" value="1" required>
                                            </div>
                                            <div class="col-12 mb-3">
                                                <label class="form-label small fw-bold">Jumlah Unit</label>
                                                <input type="number" class="form-control rounded-pill border-0 bg-light jumlah_unit" name="jumlah" min="1" max="{{ $pakaian->stok }}" value="1" required>
                                            </div>
                                            <div class="col-12">
                                                <label class="form-label small fw-bold text-muted">Estimasi Pengembalian:</label>
                                                <input type="text" class="form-control rounded-pill border-0 bg-light fw-bold text-muted tgl_selesai_display" readonly value="-">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="modal-footer border-0 pb-4 pt-3 justify-content-center">
                                <button type="button" class="btn btn-light rounded-pill px-4 me-2" data-bs-dismiss="modal">Batal</button>
                                <button type="submit" class="btn btn-orange-gradient rounded-pill px-5 shadow fw-bold">
                                    Lanjutkan Pembayaran
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        @empty
            <div class="col-12 text-center py-5">
                <p class="text-muted">Maaf, belum ada koleksi untuk kategori ini.</p>
            </div>
        @endforelse
    </div>
</div>

{{-- HTML SALES PROOF POPUP --}}
<div id="sales-proof" class="sales-toast">
    <img src="" id="sp-img" class="toast-img" alt="Product">
    <div class="toast-content">
        <p><span id="sp-user" class="fw-bold text-dark">Seseorang</span> baru saja menyewa <span id="sp-item" class="fw-bold text-orange-gradient">Produk</span></p>
        <span class="toast-time">1 menit yang lalu</span>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // 1. LOGIKA HITUNG HARGA DI MODAL
    document.querySelectorAll('.modal').forEach(modal => {
        const tglMulai = modal.querySelector('.tgl_mulai');
        const lama = modal.querySelector('.lama');
        const jumlah = modal.querySelector('.jumlah_unit');
        const totalDisplay = modal.querySelector('.total-display');
        const tglSelesaiDisplay = modal.querySelector('.tgl_selesai_display');
        const hargaSatuan = modal.querySelector('.harga_input').value;
        const depositSatuan = modal.querySelector('.deposit_input').value;

        function updateAll() {
            let l = parseInt(lama.value) || 0;
            let j = parseInt(jumlah.value) || 0;
            const totalSewa = hargaSatuan * l * j;
            const totalDeposit = depositSatuan * j;
            const grandTotal = totalSewa + totalDeposit;
            totalDisplay.innerText = "Rp " + new Intl.NumberFormat('id-ID').format(grandTotal);

            if (tglMulai.value && l) {
                let date = new Date(tglMulai.value);
                date.setDate(date.getDate() + l);
                tglSelesaiDisplay.value = date.toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
            }
        }
        [tglMulai, lama, jumlah].forEach(el => el.addEventListener('input', updateAll));
        updateAll();
    });

    // 2. LOGIKA SALES PROOF POPUP
    const dataPakaian = @json($pakaians->take(10));
    const namaUser = ["Andini", "Rahmat", "Siti Nurhaliza", "Budi Santoso", "Dewi Kartika", "Rizky", "Amelia", "Fahmi"];
    const toast = document.getElementById('sales-proof');

    function showPopup() {
        if (dataPakaian.length === 0) return;
        
        const randomPak = dataPakaian[Math.floor(Math.random() * dataPakaian.length)];
        const randomNam = namaUser[Math.floor(Math.random() * namaUser.length)];

        document.getElementById('sp-img').src = `/storage/${randomPak.foto}`;
        document.getElementById('sp-user').innerText = randomNam;
        document.getElementById('sp-item').innerText = randomPak.nama_pakaian;

        toast.classList.add('show');
        setTimeout(() => { toast.classList.remove('show'); }, 5000);
    }

    // Muncul pertama dalam 4 detik, lalu ulang setiap 15 detik
    setTimeout(showPopup, 4000);
    setInterval(showPopup, 15000);
});
</script>
@endsection