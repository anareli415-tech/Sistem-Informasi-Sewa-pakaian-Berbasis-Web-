@extends('layout.penyedia')

@section('content')
<div class="main-content-wrapper" style="margin-left: 250px; padding: 20px;">
    <div class="container-fluid">
        <a href="{{ route('pakaian.index') }}" class="btn btn-secondary mb-3 shadow-sm">
            <i class="fas fa-arrow-left me-2"></i>Kembali ke Katalog
        </a>
        
        <div class="card shadow border-0 rounded-3">
            <div class="card-header bg-primary text-white py-3">
                <h5 class="mb-0 fw-bold">Daftar Penyewa: {{ $pakaian->nama_pakaian }}</h5>
            </div>
            <div class="card-body p-0">
                @if($pelangganSewa->isEmpty())
                    <div class="text-center py-5">
                        <i class="fas fa-user-slash fa-3x text-muted mb-3"></i>
                        <p class="text-muted">Belum ada penyewa untuk baju ini.</p>
                    </div>
                @else
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="bg-light">
                            <tr>
                                <th class="ps-4">Pelanggan</th>
                                <th>Tanggal Sewa</th>
                                <th>Total & Deposit</th>
                                <th>Status</th>
                                <th class="text-center pe-4">Aksi Konfirmasi</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($pelangganSewa as $item)
                            <tr>
                                <td class="ps-4">
                                    <div class="fw-bold text-dark">{{ $item->nama }}</div>
                                    <small class="text-muted"><i class="fas fa-phone-alt me-1"></i>{{ $item->ponsel }}</small>
                                </td>
                                <td>
                                    <small class="d-block fw-bold text-primary">{{ date('d M Y', strtotime($item->tgl_mulai)) }}</small>
                                    <small class="text-muted">s/d {{ date('d M Y', strtotime($item->tgl_selesai)) }}</small>
                                </td>
                                <td>
                                    <div class="fw-bold">Total: Rp {{ number_format($item->total_bayar, 0, ',', '.') }}</div>
                                    <div class="badge bg-light text-success border small">
                                        Deposit: Rp {{ number_format($item->total_deposit, 0, ',', '.') }}
                                    </div>
                                </td>
                                <td>
                                    @if($item->status == 'DIKEMBALIKAN')
                                        <span class="badge bg-warning text-dark border shadow-sm">
                                            <i class="fas fa-box-open me-1"></i>Barang Sampai?
                                        </span>
                                    @elseif($item->status == 'SELESAI')
                                        <span class="badge bg-success">Selesai (Deposit Dikembalikan)</span>
                                    @else
                                        <span class="badge bg-info">{{ $item->status }}</span>
                                    @endif
                                </td>
                                <td class="pe-4 text-center">
                                    <form action="{{ route('transaksi.updateStatus', $item->id) }}" method="POST">
                                        @csrf @method('PATCH')
                                        <div class="input-group input-group-sm">
                                            <select name="status" class="form-select border-primary" onchange="checkStatus(this, '{{ number_format($item->total_deposit, 0, ',', '.') }}')">
                                                <option value="WAIT" {{ $item->status == 'WAIT' ? 'selected' : '' }}>WAIT</option>
                                                <option value="PROSES" {{ $item->status == 'PROSES' ? 'selected' : '' }}>SEWA</option>
                                                <option value="DIKEMBALIKAN" {{ $item->status == 'DIKEMBALIKAN' ? 'selected' : '' }}>DIKEMBALIKAN</option>
                                                <option value="SELESAI" {{ $item->status == 'SELESAI' ? 'selected' : '' }}>SELESAI (Balikin Deposit)</option>
                                                <option value="BATAL" {{ $item->status == 'BATAL' ? 'selected' : '' }}>BATAL</option>
                                            </select>
                                            <button type="submit" class="btn btn-primary">Update</button>
                                        </div>
                                    </form>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
                @endif
            </div>
        </div>
    </div>
</div>

<script>
    function checkStatus(select, depositAmount) {
        if(select.value === 'SELESAI') {
            alert("KONFIRMASI: Pastikan barang sudah dicek. Dengan status SELESAI, Anda wajib mengembalikan uang deposit sebesar Rp " + depositAmount + " kepada pelanggan.");
        }
    }
</script>
@endsection