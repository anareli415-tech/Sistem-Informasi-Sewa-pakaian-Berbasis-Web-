@extends('layout.penyedia')

@section('title', 'Edit Pakaian')

@section('content')
<div class="main-content-wrapper">
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card border-0 shadow-sm rounded-4">
                    <div class="card-header bg-white border-0 pt-4 px-4">
                        <h4 class="fw-bold mb-0">Edit Informasi Pakaian</h4>
                        <p class="text-muted small">Perbarui detail koleksi pakaian Anda</p>
                    </div>
                    
                    <div class="card-body p-4">
                        @if ($errors->any())
                            <div class="alert alert-danger border-0 shadow-sm rounded-3">
                                <ul class="mb-0">
                                    @foreach ($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                    @endforeach
                                </ul>
                            </div>
                        @endif

                        <form action="{{ route('pakaian.update', $pakaian->id) }}" 
                              method="POST" 
                              enctype="multipart/form-data">
                            @csrf
                            @method('PUT')

                            <div class="mb-3">
                                <label class="form-label fw-semibold">Nama Pakaian</label>
                                <input type="text" class="form-control rounded-3" name="nama_pakaian" 
                                       value="{{ old('nama_pakaian', $pakaian->nama_pakaian) }}" placeholder="Contoh: Jas Hitam Slim Fit" required>
                            </div>

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label fw-semibold">Jenis</label>
                                    <select class="form-select rounded-3" name="jenis" required>
                                        @foreach (['formal','adat/tradisional','pesta','kasual','kostum/cosplay','olahraga'] as $jenis)
                                            <option value="{{ $jenis }}" 
                                                {{ old('jenis', $pakaian->jenis) == $jenis ? 'selected' : '' }}>
                                                {{ ucfirst($jenis) }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>

                                {{-- CHECKBOX UKURAN --}}
                                <div class="col-md-12 mb-3">
                                    <label class="form-label fw-semibold d-block">Pilihan Ukuran</label>
                                    <div class="size-checkbox-group">
                                        @php
                                            // Daftar semua ukuran yang mungkin
                                            $available_sizes = ['S', 'M', 'L', 'XL', 'XXL', 'All Size'];
                                            
                                            // Mengambil data ukuran dari DB dan dipecah jadi array
                                            // Kita gunakan trim untuk hapus spasi tak sengaja
                                            $current_sizes = explode(',', $pakaian->ukuran);
                                            $current_sizes = array_map('trim', $current_sizes);
                                        @endphp

                                        @foreach($available_sizes as $size)
                                            <div class="form-check form-check-inline mb-2">
                                                <input class="btn-check" type="checkbox" name="ukuran[]" 
                                                       value="{{ $size }}" 
                                                       id="size{{ $size }}"
                                                       {{ in_array($size, $current_sizes) ? 'checked' : '' }}>
                                                <label class="btn btn-outline-primary rounded-3 px-3 fw-bold" for="size{{ $size }}">
                                                    {{ $size }}
                                                </label>
                                            </div>
                                        @endforeach
                                    </div>
                                    <small class="text-muted">*Centang ukuran yang tersedia untuk pakaian ini.</small>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <label class="form-label fw-semibold">Stok Unit</label>
                                    <input type="number" class="form-control rounded-3" name="stok" 
                                           value="{{ old('stok', $pakaian->stok) }}" min="0" required>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label class="form-label fw-semibold">Harga Sewa /Hari</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light border-end-0">Rp</span>
                                        <input type="number" class="form-control border-start-0 rounded-end-3" name="harga" 
                                               value="{{ old('harga', $pakaian->harga) }}" required>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label class="form-label fw-semibold text-danger">Deposit (Jaminan)</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light border-end-0">Rp</span>
                                        <input type="number" class="form-control border-start-0 rounded-end-3" name="deposit" 
                                               value="{{ old('deposit', $pakaian->deposit) }}" required>
                                    </div>
                                    <small class="text-muted" style="font-size: 10px;">*Uang jaminan yang dikembalikan</small>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label class="form-label fw-semibold">Deskripsi</label>
                                <textarea class="form-control rounded-3" name="deskripsi" rows="4" placeholder="Ceritakan detail bahan, kondisi, atau kelengkapan...">{{ old('deskripsi', $pakaian->deskripsi) }}</textarea>
                            </div>

                            <div class="mb-4">
                                <label class="form-label fw-semibold">Foto Pakaian</label>
                                <div class="row align-items-center">
                                    <div class="col-auto">
                                        @if ($pakaian->foto)
                                            <img src="{{ asset('storage/'.$pakaian->foto) }}" 
                                                 class="img-thumbnail rounded-3 shadow-sm" 
                                                 width="120" id="preview-img">
                                        @else
                                            <div class="bg-light rounded-3 d-flex align-items-center justify-content-center border" style="width:120px; height:120px;">
                                                <i class="fas fa-image text-muted fa-2x"></i>
                                            </div>
                                        @endif
                                    </div>
                                    <div class="col">
                                        <input type="file" name="foto" class="form-control rounded-3 mb-2" onchange="previewImage(this)">
                                        <small class="text-muted d-block italic">Kosongkan jika tidak ingin mengganti foto. Format: JPG, PNG, Max 2MB.</small>
                                    </div>
                                </div>
                            </div>

                            <hr class="my-4">

                            <div class="d-flex gap-2">
                                <button type="submit" class="btn btn-primary px-4 rounded-pill shadow-sm">
                                    <i class="fas fa-save me-2"></i>Simpan Perubahan
                                </button>
                                <a href="{{ route('pakaian.index') }}" class="btn btn-light px-4 rounded-pill border">
                                    Batal
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .main-content-wrapper { 
        margin-left: 250px; 
        background-color: #f8f9fa; 
        min-height: 100vh; 
        transition: 0.3s; 
    }
    
    /* Style tombol checkbox */
    .btn-check:checked + .btn-outline-primary {
        background-color: #0d6efd;
        color: white;
        box-shadow: 0 4px 8px rgba(13, 110, 253, 0.3);
    }

    .form-control:focus, .form-select:focus {
        border-color: #0d6efd;
        box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.1);
    }
    
    @media (max-width: 768px) {
        .main-content-wrapper { margin-left: 0; }
    }
</style>

<script>
    function previewImage(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                document.getElementById('preview-img').src = e.target.result;
            }
            reader.readAsDataURL(input.files[0]);
        }
    }
</script>
@endsection