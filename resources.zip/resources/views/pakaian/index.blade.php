@extends('layout.penyedia')

@section('title', 'Katalog Koleksi Pakaian')

@section('content')
<div class="main-content-wrapper">
    <div class="container-fluid py-4 px-lg-5">

        {{-- HEADER SECTION --}}
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
            <div class="header-text">
                <h4 class="fw-bold text-dark mb-1">Katalog Koleksi Pakaian</h4>
                <p class="text-muted small mb-0"><i class="fas fa-store-alt me-1 text-primary"></i> Kelola item penyewaan toko Anda secara real-time.</p>
            </div>
            <a href="{{ route('pakaian.create') }}" class="btn btn-primary rounded-pill px-4 shadow-sm hover-elevate">
                <i class="fas fa-plus-circle me-2"></i>Tambah Koleksi Baru
            </a>
        </div>

        {{-- NOTIFIKASI SUCCESS --}}
        @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show border-0 shadow-sm mb-4 custom-alert" role="alert">
                <div class="d-flex align-items-center">
                    <div class="alert-icon-circle bg-success text-white me-3">
                        <i class="fas fa-check"></i>
                    </div>
                    <div class="fw-medium">{{ session('success') }}</div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif

        {{-- GRID KATALOG --}}
        <div class="row row-cols-2 row-cols-md-3 row-cols-lg-4 g-4">
            @forelse($pakaians as $pakaian)
            <div class="col">
                <div class="card h-100 border-0 shadow-sm card-pakaian">
                    
                    {{-- AREA GAMBAR DENGAN OVERLAY ACTION --}}
                    <div class="position-relative overflow-hidden card-img-container">
                        <div class="aspect-ratio-box">
                            <img src="{{ $pakaian->foto ? asset('storage/'.$pakaian->foto) : 'https://placehold.co/500x600?text=No+Image' }}" 
                                 class="card-img-top img-katalog" 
                                 alt="{{ $pakaian->nama_pakaian }}">
                        </div>

                        {{-- Badge Stok (Warna dinamis) --}}
                        <div class="status-badges">
                            <span class="badge {{ $pakaian->stok > 0 ? 'bg-success' : 'bg-danger' }} glass-badge">
                                {{ $pakaian->stok > 0 ? 'Stok: '.$pakaian->stok : 'Habis' }}
                            </span>
                        </div>

                        {{-- Glassmorphism Overlay Buttons --}}
                        <div class="action-overlay-glass">
                            <div class="d-flex gap-2">
                                <a href="{{ route('pakaian.edit', $pakaian->id) }}" class="btn-glass-action edit" title="Edit Item">
                                    <i class="fas fa-pencil-alt"></i>
                                </a>
                                <form action="{{ route('pakaian.destroy', $pakaian->id) }}" method="POST" onsubmit="return confirm('Hapus item ini dari katalog?')">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn-glass-action delete" title="Hapus Item">
                                        <i class="fas fa-trash-alt"></i>
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>

                    {{-- DETAIL INFO --}}
                    <div class="card-body p-3 d-flex flex-column">
                        <div class="mb-2">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <span class="badge bg-light text-primary border-primary-subtle border" style="font-size: 10px;">{{ ucfirst($pakaian->jenis) }}</span>
                                <div class="text-end">
                                    {{-- Menampilkan ukuran sebagai label kecil --}}
                                    @php $sizeArray = explode(',', $pakaian->ukuran); @endphp
                                    @foreach(array_slice($sizeArray, 0, 2) as $s)
                                        <span class="badge bg-dark-subtle text-dark" style="font-size: 9px;">{{ trim($s) }}</span>
                                    @endforeach
                                    @if(count($sizeArray) > 2)
                                        <span class="badge bg-secondary" style="font-size: 9px;">+{{ count($sizeArray)-2 }}</span>
                                    @endif
                                </div>
                            </div>
                            <h6 class="fw-bold mb-1 text-dark text-truncate-2" title="{{ $pakaian->nama_pakaian }}">
                                {{ $pakaian->nama_pakaian }}
                            </h6>
                        </div>

                        <div class="mt-auto">
                            <div class="price-tag mb-3">
                                <span class="text-muted small">Harga Sewa</span>
                                <h5 class="fw-bold text-primary mb-0">Rp {{ number_format($pakaian->harga, 0, ',', '.') }}<small class="text-muted" style="font-size: 11px;">/hari</small></h5>
                            </div>

                            <a href="{{ route('pakaian.riwayat', $pakaian->id) }}" class="btn btn-info-soft w-100 rounded-pill btn-sm fw-bold py-2">
                                <i class="fas fa-history me-1"></i> Riwayat Sewa
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            @empty
            <div class="col-12 w-100">
                <div class="text-center py-5 bg-white rounded-4 shadow-sm border border-dashed">
                    <div class="empty-state-icon mb-3">
                        <i class="fas fa-box-open fa-4x text-light"></i>
                    </div>
                    <h5 class="text-dark fw-bold">Belum Ada Koleksi</h5>
                    <p class="text-muted small">Mulai tambahkan koleksi pakaian Anda untuk menyewakan.</p>
                    <a href="{{ route('pakaian.create') }}" class="btn btn-primary mt-2 rounded-pill px-4">
                        <i class="fas fa-plus me-2"></i>Buat Item Pertama
                    </a>
                </div>
            </div>
            @endforelse
        </div>
    </div>
</div>

<style>
    /* Dasar Layout */
    .main-content-wrapper { 
        margin-left: 250px; 
        background-color: #f8fafc; 
        min-height: 100vh; 
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }

    /* Aspect Ratio Container */
    .aspect-ratio-box {
        position: relative;
        width: 100%;
        padding-top: 133%; 
        overflow: hidden;
        background-color: #f1f5f9;
    }

    .img-katalog {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform 0.6s cubic-bezier(0.4, 0, 0.2, 1);
    }

    /* Card Styling */
    .card-pakaian {
        border-radius: 16px;
        transition: all 0.4s ease;
        overflow: hidden;
        border: 1px solid #e2e8f0;
    }

    .card-pakaian:hover {
        transform: translateY(-10px);
        box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1) !important;
    }

    .card-pakaian:hover .img-katalog {
        transform: scale(1.1);
    }

    /* Overlay Glassmorphism */
    .action-overlay-glass {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.2);
        display: flex;
        justify-content: center;
        align-items: center;
        opacity: 0;
        transition: all 0.3s ease;
        backdrop-filter: blur(2px);
    }

    .card-pakaian:hover .action-overlay-glass {
        opacity: 1;
    }

    .btn-glass-action {
        width: 40px;
        height: 40px;
        border-radius: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: white;
        color: #1e293b;
        border: none;
        transition: all 0.2s;
    }

    .btn-glass-action.edit:hover { background: #ffc107; color: white; }
    .btn-glass-action.delete:hover { background: #ef4444; color: white; }

    /* Badges */
    .status-badges {
        position: absolute;
        top: 10px;
        left: 10px;
        z-index: 2;
    }

    .glass-badge {
        backdrop-filter: blur(4px);
        background: rgba(255, 255, 255, 0.9);
        color: #1e293b !important;
        font-weight: 700;
        padding: 5px 10px;
        border-radius: 6px;
        font-size: 11px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    
    .bg-success.glass-badge { border-left: 3px solid #10b981; }
    .bg-danger.glass-badge { border-left: 3px solid #ef4444; }

    .text-truncate-2 {
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
        height: 2.5rem;
    }

    .btn-info-soft {
        background-color: #f1f5f9;
        color: #475569;
        border: 1px solid #e2e8f0;
    }

    .btn-info-soft:hover {
        background-color: #1e293b;
        color: #fff;
    }

    @media (max-width: 991.98px) {
        .main-content-wrapper { margin-left: 0; }
    }
</style>
@endsection