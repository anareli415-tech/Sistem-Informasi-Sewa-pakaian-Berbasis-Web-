@extends('layout.penyedia')
@section('title','Detail Transaksi')
@section('content')

<div class="container py-4">
    <h3>Detail Pesanan #{{ $transaksi->id }}</h3>

    <table class="table table-bordered mt-3">
        <tr><th>Nama Pelanggan</th><td>{{ $transaksi->nama }}</td></tr>
        <tr><th>Email</th><td>{{ $transaksi->user->email ?? '-' }}</td></tr>
        <tr><th>Ponsel</th><td>{{ $transaksi->ponsel }}</td></tr>
        <tr><th>Alamat</th><td>{{ $transaksi->alamat }}</td></tr>
        <tr><th>Pakaian</th><td>{{ $transaksi->pakaian->nama_pakaian ?? '-' }}</td></tr>
        <tr><th>Lama Sewa</th><td>{{ $transaksi->lama }} hari</td></tr>
        <tr><th>Tgl Mulai</th><td>{{ \Carbon\Carbon::parse($transaksi->tgl_mulai)->format('d-m-Y') }}</td></tr>
        <tr><th>Tgl Selesai</th><td>{{ \Carbon\Carbon::parse($transaksi->tgl_selesai)->format('d-m-Y') }}</td></tr>
        <tr><th>Total</th><td>Rp {{ number_format($transaksi->total,0,',','.') }}</td></tr>
        <tr><th>Status</th><td>{{ $transaksi->status }}</td></tr>
    </table>

    <a href="{{ route('transaksi.index') }}" class="btn btn-secondary mt-3">Kembali</a>
</div>

@endsection
