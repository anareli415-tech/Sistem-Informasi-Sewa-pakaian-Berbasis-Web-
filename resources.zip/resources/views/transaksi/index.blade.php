@extends('layout.penyedia')
@section('title','Daftar Transaksi')

@section('content')
<div class="container py-4">
    <h3>Transaksi Masuk</h3>

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    <table class="table table-bordered mt-3">
        <thead>
            <tr>
                <th>Kode</th>
                <th>Pelanggan</th>
                <th>Pakaian</th>
                <th>Lama</th>
                <th>Total</th>
                <th>Status</th>
                <th>Tgl Pesan</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
        @forelse($transaksis as $t)
            <tr>
                <td>{{ $t->id }}</td>
                <td>{{ $t->nama }} ({{ $t->user->email ?? '-' }})</td>
                <td>{{ $t->pakaian->nama_pakaian ?? '-' }}</td>
                <td>{{ $t->lama }} hari</td>
                <td>Rp {{ number_format($t->total_bayar,0,',','.') }}</td>
                <td>{{ $t->status }}</td>
                <td>{{ \Carbon\Carbon::parse($t->tgl_pesan)->format('d-m-Y') }}</td>
                <td>
                    <a href="{{ route('transaksi.show', ['id'=>$t->id]) }}"
                       class="btn btn-sm btn-primary mb-1">Lihat</a>

                    <form action="{{ route('transaksi.updateStatus', ['id'=>$t->id]) }}"
                          method="POST" class="d-inline">
                        @csrf
                        @method('PATCH')

                        <select name="status" class="form-select form-select-sm mb-1">
                            <option value="WAIT" {{ $t->status=='WAIT'?'selected':'' }}>WAIT</option>
                            <option value="PROSES" {{ $t->status=='PROSES'?'selected':'' }}>PROSES</option>
                            <option value="SELESAI" {{ $t->status=='SELESAI'?'selected':'' }}>SELESAI</option>
                        </select>

                        <button type="submit" class="btn btn-sm btn-success w-100">
                            Update
                        </button>
                    </form>
                </td>
            </tr>
        @empty
            <tr>
                <td colspan="8" class="text-center">Belum ada transaksi</td>
            </tr>
        @endforelse
        </tbody>
    </table>
</div>
@endsection
