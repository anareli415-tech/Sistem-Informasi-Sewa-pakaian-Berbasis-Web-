@extends('layout.pelanggan')

@section('title', 'Dashboard Pelanggan')

@section('content')
<style>
    /* 1. Latar Belakang Dashboard */
    body {
        background-color: #f0f2f5; /* Warna latar belakang dashboard yang solid & soft */
        font-family: 'Plus Jakarta Sans', sans-serif;
    }

    /* 2. Tipografi & Warna */
    .text-orange { color: #FF8C00 !important; }
    .text-orange-gradient-bold {
        background: linear-gradient(90deg, #FF8C00, #FF4500);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        font-weight: 800;
    }
    .bg-soft-orange { background: #FFF5E6; }
    .bg-dark-navy { background: #1a252f; }
    
    /* 3. Tombol Kustom */
    .btn-orange-light { 
        background: #FFF5E6; 
        color: #FF8C00; 
        font-weight: 700; 
        border: none;
        transition: all 0.3s ease;
    }
    .btn-orange-light:hover { 
        background: #FF8C00; 
        color: white; 
        transform: scale(1.05);
    }

    /* 4. Efek Kartu (Glassmorphism Light) */
    .custom-card {
        background: white;
        border: none;
        border-radius: 20px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.04);
        transition: all 0.3s ease;
    }
    
    .card-hover-orange { transition: all 0.3s ease; cursor: pointer; }
    .card-hover-orange:hover {
        transform: translateY(-8px);
        box-shadow: 0 15px 35px rgba(255, 140, 0, 0.12) !important;
    }
    .card-hover-orange:hover .icon-box {
        background: linear-gradient(135deg, #FF8C00 0%, #FF4500 100%) !important;
        color: white !important;
    }

    .icon-box {
        transition: all 0.3s ease;
    }

    .rotate-15 { transform: rotate(-15deg); }
    
    /* Utility */
    .fw-800 { font-weight: 800; }
    .object-cover { object-fit: cover; }
</style>

<div class="container py-4">
    {{-- 1. WELCOME BANNER --}}
    <div class="row mb-4">
        <div class="col-12">
            <div class="custom-card p-5 position-relative overflow-hidden">
                {{-- Dekorasi Latar --}}
                <div class="position-absolute top-0 end-0 p-4 opacity-10">
                    <i class="fas fa-sparkles fa-10x text-orange rotate-15"></i>
                </div>
                
                <div class="position-relative" style="z-index: 2;">
                    <h2 class="fw-800" style="color: #333;">Halo, 
                        <span class="text-orange-gradient-bold">
                            {{ auth()->user()->name }}
                        </span>! ✨
                    </h2>
                    <p class="text-muted fs-5 mb-0">Siap tampil beda dengan koleksi terbaik kami?</p>
                    <div class="mt-3" style="width: 80px; height: 6px; background: linear-gradient(90deg, #FF8C00, #FF4500); border-radius: 10px;"></div>
                </div>
            </div>
        </div>
    </div>

    {{-- 2. MAIN MENU CARDS --}}
    <div class="row g-4 mb-5">
        <div class="col-md-4">
            <a href="{{ route('kategori.index') }}" class="text-decoration-none">
                <div class="custom-card p-4 h-100 card-hover-orange">
                    <div class="d-flex align-items-center">
                        <div class="rounded-4 p-3 me-3 icon-box bg-soft-orange text-orange">
                            <i class="fa fa-shuttle-space fa-2xl"></i>
                        </div>
                        <div>
                            <h5 class="fw-bold text-dark mb-0">Jelajah Gaya</h5>
                            <p class="text-muted small mb-0">Temukan kostum impian</p>
                        </div>
                    </div>
                </div>
            </a>
        </div>

        <div class="col-md-4">
            <a href="{{ route('riwayat.index') }}" class="text-decoration-none">
                <div class="custom-card p-4 h-100 card-hover-orange">
                    <div class="d-flex align-items-center">
                        <div class="rounded-4 p-3 me-3 icon-box bg-soft-orange text-orange">
                            <i class="fa fa-clock-rotate-left fa-2xl"></i>
                        </div>
                        <div>
                            <h5 class="fw-bold text-dark mb-0">Pesanan Saya</h5>
                            <p class="text-muted small mb-0">Pantau proses sewa</p>
                        </div>
                    </div>
                </div>
            </a>
        </div>

        <div class="col-md-4">
            <a href="{{ route('profile') }}" class="text-decoration-none">
                <div class="custom-card p-4 h-100 card-hover-orange">
                    <div class="d-flex align-items-center">
                        <div class="rounded-4 p-3 me-3 icon-box bg-soft-orange text-orange">
                            <i class="fa fa-id-card fa-2xl"></i>
                        </div>
                        <div>
                            <h5 class="fw-bold text-dark mb-0">Profil Akun</h5>
                            <p class="text-muted small mb-0">Data diri & alamat</p>
                        </div>
                    </div>
                </div>
            </a>
        </div>
    </div>

    <div class="row g-4">
        {{-- 3. STATUS SEWA AKTIF --}}
        <div class="col-lg-8">
            <div class="custom-card p-4 h-100">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h5 class="fw-bold mb-0">
                        <i class="fas fa-truck-fast me-2 text-orange"></i>Sewa Sedang Berjalan
                    </h5>
                    <a href="{{ route('riwayat.index') }}" class="text-orange small text-decoration-none fw-bold">Lihat Semua</a>
                </div>
                
                <div class="text-center py-5 border rounded-4 border-dashed bg-light">
                    <img src="https://cdn-icons-png.flaticon.com/512/4076/4076432.png" style="width: 100px;" class="opacity-50 mb-3">
                    <h6 class="fw-bold text-dark">Belum ada sewa aktif</h6>
                    <p class="text-muted small mb-4">Yuk, cari pakaian favoritmu dan mulai menyewa!</p>
                    <a href="{{ route('kategori.index') }}" class="btn btn-orange-light rounded-pill px-5 shadow-sm">Mulai Cari</a>
                </div>
            </div>
        </div>

        {{-- 4. TRENDING/RECOMMENDED --}}
        <div class="col-lg-4">
            <div class="custom-card p-4 h-100 bg-dark-navy text-white overflow-hidden position-relative">
                <div class="position-relative" style="z-index: 2;">
                    <h5 class="fw-bold mb-4 text-orange">Trending Minggu Ini 🔥</h5>
                    
                    <div class="d-flex align-items-center mb-4 transition-all">
                        <div class="flex-shrink-0">
                            <img src="https://images.pexels.com/photos/45238/wedding-vows-marriage-happiness-45238.jpeg?auto=compress&cs=tinysrgb&w=200" class="rounded-4 shadow object-cover" width="60" height="60">
                        </div>
                        <div class="ms-3">
                            <h6 class="mb-0 small fw-bold">Jas Formal Slimfit</h6>
                            <small class="text-white-50">42x Disewa</small>
                            <div class="text-warning small mt-1">
                                <i class="fas fa-star"></i> 4.9
                            </div>
                        </div>
                    </div>

                    <div class="d-flex align-items-center mb-4 transition-all">
                        <div class="flex-shrink-0">
                            <img src="https://images.pexels.com/photos/1444442/pexels-photo-1444442.jpeg?auto=compress&cs=tinysrgb&w=200" class="rounded-4 shadow object-cover" width="60" height="60">
                        </div>
                        <div class="ms-3">
                            <h6 class="mb-0 small fw-bold">Kebaya Modern Rose</h6>
                            <small class="text-white-50">38x Disewa</small>
                            <div class="text-warning small mt-1">
                                <i class="fas fa-star"></i> 5.0
                            </div>
                        </div>
                    </div>

                    <div class="mt-4 p-3 rounded-4 bg-white bg-opacity-10 border border-white border-opacity-10 text-center">
                        <p class="small mb-0">Ingin melihat lebih banyak?</p>
                        <a href="{{ route('kategori.index') }}" class="text-orange fw-bold text-decoration-none small">Lihat Katalog <i class="fas fa-arrow-right ms-1"></i></a>
                    </div>
                </div>
                {{-- Dekorasi Fire --}}
                <i class="fas fa-fire fa-6x position-absolute end-0 bottom-0 opacity-10 mb-n3 me-n2"></i>
            </div>
        </div>
    </div>
</div>
@endsection