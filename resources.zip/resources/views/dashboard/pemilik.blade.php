@extends('layout.app')

@section('title', 'Dashboard Administrator')

@section('content')
@include('layout.sidebar_pemilik')

<div class="main-content-wrapper" style="margin-left: 260px; padding: 30px; background: #f4f7f6; min-height: 100vh;">
    <div class="container-fluid">
        
        <div class="row mb-4">
            <div class="col-md-12">
                <div class="d-flex justify-content-between align-items-center bg-white p-4 rounded-4 shadow-sm border-start border-primary border-5">
                    <div>
                        <h3 class="fw-bold text-navy mb-1">Pusat Kendali Sistem</h3>
                        <p class="text-muted mb-0">Monitor aktivitas seluruh platform <span class="fw-bold text-primary">RFA Store</span> secara real-time.</p>
                    </div>
                    <div class="text-end d-none d-md-block">
                        <div class="badge bg-primary-soft text-primary px-3 py-2 rounded-pill shadow-sm">
                            <i class="fa fa-user-shield me-2"></i> Administrator: {{ auth()->user()->name }}
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row g-4 mb-4">
            <div class="col-md-3">
                <div class="card border-0 shadow-sm rounded-4 position-relative overflow-hidden">
                    <div class="card-body p-4">
                        <small class="text-muted fw-bold text-uppercase ls-1">Total Pengguna</small>
                        <h2 class="fw-bold mb-0 mt-1">{{ number_format($totalUser ?? 0) }}</h2>
                        <p class="text-primary small mb-0 mt-2"><i class="fa fa-arrow-up"></i> Terdaftar di sistem</p>
                    </div>
                    <div class="icon-bg opacity-10 position-absolute end-0 bottom-0 me-3 mb-2">
                        <i class="fa fa-users fa-4x text-primary"></i>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card border-0 shadow-sm rounded-4 position-relative overflow-hidden">
                    <div class="card-body p-4">
                        <small class="text-muted fw-bold text-uppercase ls-1">Penyedia Aktif</small>
                        <h2 class="fw-bold mb-0 mt-1">{{ number_format($totalPenyedia ?? 0) }}</h2>
                        <p class="text-success small mb-0 mt-2"><i class="fa fa-store"></i> Toko terverifikasi</p>
                    </div>
                    <div class="icon-bg opacity-10 position-absolute end-0 bottom-0 me-3 mb-2">
                        <i class="fa fa-shop fa-4x text-success"></i>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card border-0 shadow-sm rounded-4 position-relative overflow-hidden">
                    <div class="card-body p-4">
                        <small class="text-muted fw-bold text-uppercase ls-1">Total Transaksi</small>
                        <h2 class="fw-bold mb-0 mt-1">{{ number_format($totalTransaksi ?? 0) }}</h2>
                        <p class="text-warning small mb-0 mt-2"><i class="fa fa-exchange-alt"></i> Pesanan diproses</p>
                    </div>
                    <div class="icon-bg opacity-10 position-absolute end-0 bottom-0 me-3 mb-2">
                        <i class="fa fa-shopping-basket fa-4x text-warning"></i>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card border-0 bg-navy text-white shadow rounded-4 position-relative overflow-hidden">
                    <div class="card-body p-4">
                        <small class="text-white-50 fw-bold text-uppercase ls-1">Omset Platform</small>
                        <h3 class="fw-bold mb-0 mt-1 text-warning">Rp {{ number_format($totalOmset ?? 0, 0, ',', '.') }}</h3>
                        <p class="text-white-50 small mb-0 mt-2">Volume arus kas</p>
                    </div>
                    <div class="icon-bg opacity-10 position-absolute end-0 bottom-0 me-3 mb-2">
                        <i class="fa fa-wallet fa-4x"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="row g-4">
            <div class="col-md-8">
                <div class="card border-0 shadow-sm rounded-4 p-4">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h5 class="fw-bold text-navy mb-0">Pertumbuhan Transaksi</h5>
                        <div class="dropdown">
                            <button class="btn btn-light btn-sm rounded-pill px-3" type="button" data-bs-toggle="dropdown">
                                6 Bulan Terakhir <i class="fa fa-chevron-down ms-1 small"></i>
                            </button>
                        </div>
                    </div>
                    <div style="height: 350px;">
                        <canvas id="pemilikChart"></canvas>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card border-0 shadow-sm rounded-4 p-4">
                    <h5 class="fw-bold text-navy mb-4">Penyedia Baru</h5>
                    <div class="list-group list-group-flush">
                        @forelse($penyediaBaru ?? [] as $user)
                        <div class="list-group-item px-0 border-0 mb-3 bg-transparent">
                            <div class="d-flex align-items-center">
                                <div class="avatar-circle bg-primary-soft text-primary fw-bold me-3">
                                    {{ strtoupper(substr($user->name, 0, 1)) }}
                                </div>
                                <div class="flex-grow-1">
                                    <h6 class="mb-0 fw-bold text-dark">{{ $user->name }}</h6>
                                    <small class="text-muted"><i class="fa fa-clock me-1"></i> {{ $user->created_at->diffForHumans() }}</small>
                                </div>
                                <a href="#" class="btn btn-sm btn-light rounded-circle"><i class="fa fa-chevron-right text-muted"></i></a>
                            </div>
                        </div>
                        @empty
                        <div class="text-center py-5">
                            <i class="fa fa-user-clock fa-3x text-light mb-3"></i>
                            <p class="text-muted small">Belum ada penyedia baru</p>
                        </div>
                        @endforelse
                    </div>
                    <hr>
                    <a href="#" class="btn btn-outline-primary btn-sm w-100 rounded-pill">Lihat Semua User</a>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    /* Typography & Colors */
    .text-navy { color: #1a2a6c; }
    .bg-navy { background: linear-gradient(135deg, #1a2a6c 0%, #0a1128 100%); }
    .bg-primary-soft { background: #eef2ff; }
    .ls-1 { letter-spacing: 0.5px; font-size: 0.75rem; }

    /* UI Elements */
    .avatar-circle {
        width: 45px;
        height: 45px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.1rem;
    }

    .card { transition: all 0.3s ease; }
    .card:hover { transform: translateY(-5px); box-shadow: 0 10px 20px rgba(0,0,0,0.05) !important; }

    /* Scrollbar untuk main content jika panjang */
    body { background-color: #f4f7f6; }
</style>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        const ctx = document.getElementById('pemilikChart').getContext('2d');
        
        // Gradient for chart
        const chartGradient = ctx.createLinearGradient(0, 0, 0, 400);
        chartGradient.addColorStop(0, 'rgba(26, 42, 108, 0.2)');
        chartGradient.addColorStop(1, 'rgba(26, 42, 108, 0)');

        new Chart(ctx, {
            type: 'line',
            data: {
                labels: {!! json_encode($bulan ?? []) !!},
                datasets: [{
                    label: 'Total Transaksi',
                    data: {!! json_encode($dataTransaksi ?? []) !!},
                    borderColor: '#1a2a6c',
                    borderWidth: 3,
                    backgroundColor: chartGradient,
                    fill: true,
                    tension: 0.4,
                    pointBackgroundColor: '#fff',
                    pointBorderColor: '#1a2a6c',
                    pointBorderWidth: 2,
                    pointRadius: 6,
                    pointHoverRadius: 8
                }]
            },
            options: {
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: '#1a2a6c',
                        padding: 12,
                        titleFont: { size: 14 },
                        bodyFont: { size: 13 },
                        displayColors: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: { borderDash: [5, 5], color: '#e0e0e0', drawBorder: false },
                        ticks: { color: '#888' }
                    },
                    x: {
                        grid: { display: false },
                        ticks: { color: '#888' }
                    }
                }
            }
        });
    });
</script>
@endsection