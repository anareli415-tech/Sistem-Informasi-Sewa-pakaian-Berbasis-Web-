@extends('layout.penyedia')

@section('title', 'Dashboard Penyedia')

@section('content')
<div class="main-content-wrapper" style="margin-left: 250px; padding: 30px; background: #f8f9fa; min-height: 100vh;">
    <div class="container-fluid py-2">
        <div class="row mb-5 align-items-center">
            <div class="col-md-8">
                <h3 class="fw-bold text-dark mb-1">Dashboard Bisnis Anda</h3>
                <p class="text-muted">Pantau pertumbuhan toko <span class="fw-bold text-orange">{{ auth()->user()->name }}</span> secara real-time.</p>
            </div>
            <div class="col-md-4 text-md-end">
                <div class="badge bg-orange-light text-orange px-3 py-2 rounded-pill shadow-sm">
                    <i class="fa fa-calendar me-2"></i> {{ date('d M Y') }}
                </div>
            </div>
        </div>

        <div class="row g-4 mb-5">
            <div class="col-md-4">
                <div class="card border-0 shadow-sm p-4 rounded-4 position-relative overflow-hidden h-100">
                    <div class="position-relative" style="z-index: 2;">
                        <small class="text-muted fw-bold text-uppercase">Total Stok</small>
                        <h2 class="fw-bold mt-1 mb-0">{{ number_format($totalStok) }}</h2>
                        <span class="text-primary small fw-semibold">Item Pakaian Tersedia</span>
                    </div>
                    <i class="fa fa-boxes position-absolute end-0 bottom-0 me-3 mb-3 text-orange opacity-10 fa-4x"></i>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card border-0 shadow-sm p-4 rounded-4 position-relative overflow-hidden h-100">
                    <div class="position-relative" style="z-index: 2;">
                        <small class="text-muted fw-bold text-uppercase">Total Sewa</small>
                        <h2 class="fw-bold mt-1 mb-0">{{ number_format($totalPenyewaan) }}</h2>
                        <span class="text-warning small fw-semibold">Transaksi Berhasil</span>
                    </div>
                    <i class="fa fa-shopping-cart position-absolute end-0 bottom-0 me-3 mb-3 text-orange opacity-10 fa-4x"></i>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card border-0 bg-dark-navy text-white shadow p-4 rounded-4 position-relative overflow-hidden h-100">
                    <div class="position-relative" style="z-index: 2;">
                        <small class="opacity-75 fw-bold text-uppercase">Total Omset</small>
                        <h2 class="fw-bold mt-1 mb-0 text-orange">Rp {{ number_format($totalOmset, 0, ',', '.') }}</h2>
                        <span class="small opacity-75">Pendapatan Bersih Sewa</span>
                    </div>
                    <i class="fa fa-wallet position-absolute end-0 bottom-0 me-3 mb-3 opacity-10 fa-4x"></i>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-12">
                <div class="card border-0 shadow-sm p-4 rounded-4">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <div>
                            <h5 class="fw-bold mb-0">Grafik Omset Bulanan</h5>
                            <small class="text-muted">Data pendapatan 6 bulan terakhir</small>
                        </div>
                        <div class="dropdown">
                            <i class="fa fa-ellipsis-v text-muted cursor-pointer" data-bs-toggle="dropdown"></i>
                        </div>
                    </div>
                    <div style="height: 350px;">
                        <canvas id="chartOmset"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .text-orange { color: #FF8C00 !important; }
    .bg-orange-light { background: #FFF5E6; }
    .bg-dark-navy { background: #2c3e50; }
    .card { transition: all 0.3s ease; border: 1px solid transparent; }
    .card:hover { transform: translateY(-5px); border-color: #FF8C00; }
    .cursor-pointer { cursor: pointer; }
</style>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        const ctx = document.getElementById('chartOmset').getContext('2d');
        const gradient = ctx.createLinearGradient(0, 0, 0, 400);
        gradient.addColorStop(0, '#FF8C00');
        gradient.addColorStop(1, '#FFD700');

        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: {!! json_encode($bulan) !!},
                datasets: [{
                    label: 'Omset (Rp)',
                    data: {!! json_encode($omsetPerBulan) !!},
                    backgroundColor: gradient,
                    borderRadius: 10,
                    barPercentage: 0.5
                }]
            },
            options: {
                maintainAspectRatio: false,
                plugins: { 
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: '#2c3e50',
                        padding: 15,
                        displayColors: false,
                        callbacks: {
                            label: function(context) {
                                return 'Pendapatan: Rp ' + new Intl.NumberFormat('id-ID').format(context.raw);
                            }
                        }
                    }
                },
                scales: { 
                    y: { 
                        beginAtZero: true,
                        grid: { color: '#f0f0f0', drawBorder: false },
                        ticks: {
                            callback: function(value) {
                                return 'Rp ' + value.toLocaleString();
                            }
                        }
                    },
                    x: { grid: { display: false } }
                }
            }
        });
    });
</script>
@endsection