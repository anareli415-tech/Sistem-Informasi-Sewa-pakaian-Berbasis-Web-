@extends('layout.pelanggan')

@section('content')
<div class="container my-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold text-dark">Riwayat Sewa Saya</h2>
            <p class="text-muted small">Pantau status penyewaan dan pengembalian uang deposit Anda.</p>
        </div>
    </div>

    <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="bg-dark text-white">
                    <tr>
                        <th class="ps-4">ID</th>
                        <th>PRODUK</th>
                        <th>DURASI</th>
                        <th>TOTAL BAYAR</th>
                        <th class="text-center">STATUS</th>
                        <th class="text-center pe-4">AKSI</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($riwayats as $r)
                    <tr>
                        <td class="ps-4 fw-bold">#{{ $r->id }}</td>
                        <td>
                            <div class="d-flex align-items-center">
                                <img src="{{ $r->pakaian->foto ? asset('storage/'.$r->pakaian->foto) : 'https://placehold.co/50x50' }}" 
                                     class="rounded-3 me-3" width="50" height="50" style="object-fit: cover;">
                                <div>
                                    <div class="fw-bold text-dark">{{ $r->pakaian->nama_pakaian }}</div>
                                    <small class="text-muted">Deposit: Rp {{ number_format($r->total_deposit, 0, ',', '.') }}</small>
                                </div>
                            </div>
                        </td>
                        <td>
                            <span class="d-block fw-bold">{{ $r->lama }} Hari</span>
                            <small class="text-muted">{{ date('d M', strtotime($r->tgl_mulai)) }} - {{ date('d M Y', strtotime($r->tgl_selesai)) }}</small>
                        </td>
                        <td>
                            <div class="fw-bold text-primary">Rp {{ number_format($r->total_bayar, 0, ',', '.') }}</div>
                            @if($r->status == 'SELESAI')
                                <small class="text-success"><i class="fas fa-check-circle"></i> Deposit Dikembalikan</small>
                            @else
                                <small class="text-muted" style="font-size: 10px;">(Sewa + Deposit)</small>
                            @endif
                        </td>
                        <td class="text-center">
                            @if($r->status == 'DIKEMBALIKAN')
                                <span class="badge bg-warning text-dark rounded-pill">Pengecekan Barang</span>
                            @elseif($r->status == 'SELESAI')
                                <span class="badge bg-success rounded-pill">Selesai</span>
                            @else
                                <span class="badge bg-info rounded-pill">{{ $r->status }}</span>
                            @endif
                        </td>
                        <td class="text-center pe-4">
                            @if($r->status == 'PROSES')
                                <a href="{{ route('pengembalian.index') }}" class="btn btn-sm btn-danger rounded-pill px-3 shadow-sm">
                                    Kembalikan
                                </a>
                            @elseif($r->status == 'DIKEMBALIKAN')
                                <span class="text-muted small italic">Verifikasi Admin...</span>
                            @elseif($r->status == 'SELESAI')
                                <i class="fas fa-check-double text-success"></i>
                            @else
                                <span class="text-muted">-</span>
                            @endif
                        </td>
                    </tr>
                    @empty
                    <tr><td colspan="6" class="text-center py-5">Belum ada riwayat transaksi.</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection