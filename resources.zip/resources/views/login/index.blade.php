<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>RFA Store - Penyewaan Pakaian Terbaik</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="{{ asset('assets/css/bootstrap.min.css') }}" rel="stylesheet">

    <style>
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: #f8f9fa;
            overflow-x: hidden;
        }

        .login-container {
            min-height: 100vh;
        }

        /* Sisi Kiri: Pengenalan / Branding */
        .intro-section {
            background: linear-gradient(135deg, rgba(255, 140, 0, 0.9), rgba(255, 69, 0, 0.9)), 
                        url('https://images.pexels.com/photos/994517/pexels-photo-994517.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1');
            background-size: cover;
            background-position: center;
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: center;
            padding: 80px;
        }

        .bg-orange-gradient {
            background: linear-gradient(90deg, #FF8C00, #FF4500);
        }

        .text-orange { color: #FF8C00; }

        .btn-orange {
            background: linear-gradient(90deg, #FF8C00, #FF4500);
            color: white;
            border: none;
            transition: 0.3s;
        }

        .btn-orange:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(255, 69, 0, 0.3);
            color: white;
        }

        .login-card {
            border: none;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.05);
        }

        .form-control {
            border-radius: 12px;
            padding: 12px 15px;
            border: 1px solid #eee;
        }

        .form-control:focus {
            box-shadow: none;
            border-color: #FF8C00;
        }

        @media (max-width: 768px) {
            .intro-section { display: none; }
        }
    </style>
</head>

<body>
    <div class="container-fluid p-0 login-container">
        <div class="row g-0 min-vh-100">
            
            <div class="col-lg-7 intro-section d-none d-lg-flex">
                <div class="mb-4">
                    <div class="d-inline-block p-3 rounded-4 bg-white mb-3 shadow">
                        <i class="fa fa-shirt fa-3x text-orange"></i>
                    </div>
                    <h1 class="display-4 fw-bold">RFA<span class="text-dark">Store</span></h1>
                </div>
                <h2 class="fw-bold mb-3">Tampil Memukau Tanpa Harus Membeli.</h2>
                <p class="fs-5 opacity-90 mb-5" style="max-width: 600px;">
                    Platform penyewaan pakaian terlengkap untuk segala momen spesialmu. 
                    Mulai dari Jas Formal, Kebaya Tradisional, hingga Kostum unik, semua ada di sini.
                </p>
                
                <div class="d-flex gap-4">
                    <div class="d-flex align-items-center">
                        <i class="fa fa-check-circle me-2 fs-4"></i>
                        <span>Koleksi Premium</span>
                    </div>
                    <div class="d-flex align-items-center">
                        <i class="fa fa-check-circle me-2 fs-4"></i>
                        <span>Harga Terjangkau</span>
                    </div>
                    <div class="d-flex align-items-center">
                        <i class="fa fa-check-circle me-2 fs-4"></i>
                        <span>Proses Mudah</span>
                    </div>
                </div>
            </div>

            <div class="col-lg-5 d-flex align-items-center justify-content-center bg-white">
                <div class="p-4 p-sm-5 w-100" style="max-width: 500px;">
                    
                    <div class="text-center mb-5 d-lg-none">
                        <h2 class="fw-bold text-orange">RFA Store</h2>
                    </div>

                    <div class="mb-4">
                        <h3 class="fw-bold text-dark">Selamat Datang Kembali!</h3>
                        <p class="text-muted small">Silakan masuk ke akun Anda untuk mulai menyewa.</p>
                    </div>

                    @if ($errors->has('email'))
                        <div class="alert alert-danger rounded-4 small">
                            <i class="fas fa-exclamation-circle me-2"></i> {{ $errors->first('email') }}
                        </div>
                    @endif

                    <form action="{{ route('login.proses') }}" method="POST">
                        @csrf

                        <div class="mb-3">
                            <label class="form-label small fw-bold">Alamat Email</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light border-0"><i class="fa fa-envelope text-muted"></i></span>
                                <input type="email" name="email" class="form-control bg-light border-0" value="{{ old('email') }}" placeholder="contoh@email.com" required>
                            </div>
                        </div>

                        <div class="mb-4">
                            <label class="form-label small fw-bold">Kata Sandi</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light border-0"><i class="fa fa-lock text-muted"></i></span>
                                <input type="password" name="password" class="form-control bg-light border-0" placeholder="••••••••" required>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-orange w-100 py-3 rounded-pill fw-bold shadow-sm mb-4">
                            Masuk Sekarang
                        </button>
                    </form>

                    <p class="text-center text-muted mb-0">
                        Belum punya akun? 
                        <a href="{{ route('register') }}" class="text-orange fw-bold text-decoration-none">Daftar Sekarang</a>
                    </p>

                </div>
            </div>

        </div>
    </div>

    <script src="{{ asset('assets/js/bootstrap.bundle.min.js') }}"></script>
</body>
</html>