@extends('layout.penyedia')

@section('title', 'Profil Toko')

@section('content')
<div class="main-content-wrapper d-flex justify-content-center" 
     style="margin-left: 280px; padding: 40px 20px; background: #f8f9fa; min-height: 100vh;">
    
    <div class="container-fluid py-2" style="max-width: 900px;">
        
        <div class="row">
            <div class="col-12">
                {{-- Breadcrumb / Header --}}
                <div class="mb-4">
                    <h3 class="fw-bold text-dark mb-1">Pengaturan Profil</h3>
                    <p class="text-muted">Kelola informasi toko dan identitas publik Anda di RFA Store.</p>
                </div>

                @if(session('success'))
                    <div class="alert alert-success border-0 shadow-sm rounded-4 mb-4">
                        <i class="fas fa-check-circle me-2"></i> {{ session('success') }}
                    </div>
                @endif

                <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
                    {{-- Header Dekorasi --}}
                    <div style="height: 120px; background: linear-gradient(135deg, #1a252f 0%, #000000 100%);"></div>
                    
                    <div class="card-body px-4 pb-4" style="margin-top: -60px;">
                        <form action="{{ route('profile.update') }}" method="POST" enctype="multipart/form-data">
                            @csrf

                            {{-- Foto Profile Section --}}
                            <div class="text-center mb-5">
                                <div class="position-relative d-inline-block">
                                    <img 
                                        id="profile-preview"
                                        src="{{ $user->foto ? asset('storage/profile/'.$user->foto) : asset('assets/img/default-user.png') }}" 
                                        class="rounded-circle border border-4 border-white shadow"
                                        style="width:140px; height:140px; object-fit:cover; background-color: #eee;"
                                    >
                                    <label for="foto-input" class="position-absolute bottom-0 end-0 bg-orange-gradient text-white rounded-circle d-flex align-items-center justify-content-center shadow-sm cursor-pointer" 
                                           style="width: 40px; height: 40px; border: 3px solid white;">
                                        <i class="fas fa-camera fa-sm"></i>
                                    </label>
                                    <input type="file" id="foto-input" name="foto" class="d-none" accept="image/*" onchange="previewImage(this)">
                                </div>
                                <h5 class="mt-3 fw-bold mb-0">{{ $user->name }}</h5>
                                <span class="badge bg-soft-orange text-orange px-3">Verified Penyedia</span>
                            </div>

                            <div class="row g-4">
                                {{-- Nama Toko --}}
                                <div class="col-md-6">
                                    <label class="form-label fw-bold text-muted small text-uppercase">Nama Toko / Penyedia</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light border-0"><i class="fas fa-store text-muted"></i></span>
                                        <input type="text" name="name" class="form-control bg-light border-0 py-2" value="{{ $user->name }}" placeholder="Masukkan nama toko">
                                    </div>
                                </div>

                                {{-- WhatsApp --}}
                                <div class="col-md-6">
                                    <label class="form-label fw-bold text-muted small text-uppercase">No. WhatsApp</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light border-0"><i class="fab fa-whatsapp text-muted"></i></span>
                                        <input type="text" name="no_hp" class="form-control bg-light border-0 py-2" value="{{ $user->no_hp }}" placeholder="0812xxxx">
                                    </div>
                                </div>

                                {{-- Alamat --}}
                                <div class="col-12">
                                    <label class="form-label fw-bold text-muted small text-uppercase">Alamat Lengkap</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light border-0"><i class="fas fa-map-marker-alt text-muted"></i></span>
                                        <input type="text" name="alamat" class="form-control bg-light border-0 py-2" value="{{ $user->alamat }}" placeholder="Alamat fisik toko Anda">
                                    </div>
                                </div>

                                {{-- Deskripsi --}}
                                <div class="col-12">
                                    <label class="form-label fw-bold text-muted small text-uppercase">Deskripsi Toko</label>
                                    <textarea name="deskripsi" class="form-control bg-light border-0 py-2" rows="4" placeholder="Ceritakan tentang spesialisasi pakaian Anda...">{{ $user->deskripsi }}</textarea>
                                </div>
                            </div>

                            <hr class="my-5 opacity-50">

                            <div class="d-flex justify-content-between align-items-center">
                                <p class="small text-muted mb-0"><i class="fas fa-info-circle me-1"></i> Perubahan akan langsung terlihat di sidebar.</p>
                                <button type="submit" class="btn btn-orange-gradient px-5 py-2 rounded-pill fw-bold shadow-sm">
                                    Simpan Profil
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    /* Styling Persis Tema Sidebar */
    .bg-orange-gradient { 
        background: linear-gradient(135deg, #FF8C00 0%, #FF4500 100%); 
    }
    .btn-orange-gradient {
        background: linear-gradient(135deg, #FF8C00 0%, #FF4500 100%);
        color: white;
        border: none;
        transition: all 0.3s ease;
    }
    .btn-orange-gradient:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(255, 69, 0, 0.3);
        color: white;
    }
    .text-orange { color: #FF8C00 !important; }
    .bg-soft-orange { background: rgba(255, 140, 0, 0.1); }
    .cursor-pointer { cursor: pointer; }
    
    .form-control:focus {
        background-color: #fff !important;
        border-color: #FF8C00 !important;
        box-shadow: 0 0 0 0.25rem rgba(255, 140, 0, 0.1);
    }

    .main-content-wrapper {
        transition: all 0.3s ease;
    }

    @media (max-width: 992px) {
        .main-content-wrapper { margin-left: 0 !important; }
    }
</style>

<script>
    // Fungsi Preview Gambar
    function previewImage(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                document.getElementById('profile-preview').src = e.target.result;
            }
            reader.readAsDataURL(input.files[0]);
        }
    }
</script>
@endsection