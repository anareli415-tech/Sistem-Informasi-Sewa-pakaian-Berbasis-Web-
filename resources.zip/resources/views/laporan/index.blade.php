@extends('layout.penyedia')

@section('content')
<div class="main-content-wrapper" style="margin-left: 250px; padding: 30px; background-color: #f8f9fa; min-height: 100vh;">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fw-bold text-dark">Laporan Keuangan</h2>
            <button onclick="window.print()" class="btn btn-dark shadow-sm px-4 rounded-pill">
                <i class="fas fa-print me-2"></i> Cetak Laporan
            </button>
        </div>

        <div class="card border-0 shadow-sm rounded-4 mb-4">
            <div class="card-body p-4">
                {{-- Action harus mengarah ke laporan.index --}}
                <form action="{{ route('laporan.index') }}" method="GET" class="row g-3 align-items-end">
                    <div class="col-md-4">
                        <label class="form-label small fw-bold text-muted">DARI TANGGAL</label>
                        <input type="date" name="start" value="{{ $start }}" class="form-control rounded-3">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label small fw-bold text-muted">SAMPAI TANGGAL</label>
                        <input type="date" name="end" value="{{ $end }}" class="form-control rounded-3">
                    </div>
                    <div class="col-md-4 d-flex gap-2">
                        <button type="submit" class="btn btn-primary w-100 fw-bold rounded-3">FILTER</button>
                        <a href="{{ route('laporan.index') }}" class="btn btn-outline-secondary w-100 fw-bold rounded-3">RESET</a>
                    </div>
                </form>
            </div>
        </div>

        <div class="row g-4 mb-4">
            <div class="col-md-4">
                <div class="card border-0 shadow-sm rounded-4 h-100">
                    <div class="card-body">
                        <div class="d-flex align-items-center mb-3">
                            <div class="bg-primary bg-opacity-10 p-3 rounded-3 me-3">
                                <i class="fas fa-shopping-cart text-primary"></i>
                            </div>
                            <span class="text-muted fw-bold small">TOTAL TRANSAKSI</span>
                        </div>
                        <h3 class="fw-bold mb-0">{{ $totalTransaksi }}</h3>
                        <small class="text-muted">Pesanan Berhasil</small>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card border-0 shadow-sm rounded-4 h-100">
                    <div class="card-body">
                        <div class="d-flex align-items-center mb-3">
                            <div class="bg-success bg-opacity-10 p-3 rounded-3 me-3">
                                <i class="fas fa-wallet text-success"></i>
                            </div>
                            <span class="text-muted fw-bold small">PENDAPATAN BERSIH</span>
                        </div>
                        <h3 class="fw-bold mb-0 text-success">Rp {{ number_format($totalPendapatan, 0, ',', '.') }}</h3>
                        <small class="text-muted text-uppercase" style="font-size: 10px;">(Hanya Uang Sewa)</small>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card border-0 shadow-sm rounded-4 h-100">
                    <div class="card-body">
                        <div class="d-flex align-items-center mb-3">
                            <div class="bg-warning bg-opacity-10 p-3 rounded-3 me-3">
                                <i class="fas fa-hand-holding-usd text-warning"></i>
                            </div>
                            <span class="text-muted fw-bold small">DEPOSIT DITAHAN</span>
                        </div>
                        <h3 class="fw-bold mb-0 text-warning">Rp {{ number_format($totalDepositDitahan, 0, ',', '.') }}</h3>
                        <small class="text-muted">Belum dikembalikan ke user</small>
                    </div>
                </div>
            </div>
        </div>

        <div class="card border-0 shadow-sm rounded-4 text-dark">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0 fw-bold">Rincian Transaksi</h5>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="bg-light">
                            <tr>
                                <th class="ps-4">ID</th>
                                <th>Pelanggan</th>
                                <th>Produk</th>
                                <th>Tgl Pesan</th>
                                <th class="text-end">Uang Sewa</th>
                                <th class="text-end">Deposit</th>
                                <th class="text-center pe-4">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse ($transaksi as $t)
                            <tr>
                                <td class="ps-4 fw-bold">#{{ $t->id }}</td>
                                <td>{{ $t->nama }}</td>
                                <td>{{ $t->pakaian->nama_pakaian ?? '-' }}</td>
                                <td>{{ date('d/m/Y', strtotime($t->tgl_pesan)) }}</td>
                                <td class="text-end fw-bold text-primary">Rp {{ number_format($t->total_sewa, 0, ',', '.') }}</td>
                                <td class="text-end">Rp {{ number_format($t->total_deposit, 0, ',', '.') }}</td>
                                <td class="text-center pe-4">
                                    @if($t->status == 'SELESAI')
                                        <span class="badge bg-success-subtle text-success px-3 rounded-pill">Selesai</span>
                                    @else
                                        <span class="badge bg-info-subtle text-info px-3 rounded-pill">{{ $t->status }}</span>
                                    @endif
                                </td>
                            </tr>
                            @empty
                            <tr>
                                <td colspan="7" class="text-center py-5 text-muted">Tidak ada transaksi ditemukan.</td>
                            </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .bg-success-subtle { background-color: #d1e7dd; color: #0f5132; }
    .bg-info-subtle { background-color: #cff4fc; color: #055160; }
    .table thead th { font-size: 12px; color: #6c757d; border-bottom: 1px solid #eee; }
    @media print {
        .main-content-wrapper { margin-left: 0 !important; padding: 0 !important; }
        .btn, form { display: none !important; }
    }
</style>
@endsection