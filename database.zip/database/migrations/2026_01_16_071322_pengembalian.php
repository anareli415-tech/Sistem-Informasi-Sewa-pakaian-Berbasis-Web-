<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
  public function up()
{
    Schema::create('pengembalians', function (Blueprint $table) {
        $table->id();
        $table->foreignId('transaksi_id')->constrained('transaksis')->onDelete('cascade');
        $table->dateTime('tgl_kembali_aktual');
        $table->decimal('denda', 15, 2)->default(0);
        $table->string('kondisi'); // Baik, Rusak Ringan, Rusak Berat
        $table->text('catatan')->nullable();
        $table->timestamps();
    });
}

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('transaksis', function (Blueprint $table) {
            $table->dropColumn(['tgl_kembali_aktual', 'denda', 'catatan_pengembalian']);
        });
    }
};