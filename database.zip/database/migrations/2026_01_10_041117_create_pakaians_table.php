<?php

use App\Models\User;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
     
  public function up(): void
{
    Schema::create('pakaians', function (Blueprint $table) {
        $table->id();
        $table->foreignId('user_id')->constrained()->onDelete('cascade');
        $table->string('nama_pakaian');
        $table->enum('jenis', ['formal', 'adat/tradisional', 'pesta','kasual','kostum/cosplay','olahraga']);
        $table->string('ukuran');
        $table->integer('stok');
        $table->integer('harga'); // Harga sewa
        $table->integer('deposit'); // <--- TAMBAHKAN INI (Harga Jaminan)
        $table->text('deskripsi');
        $table->string('foto');
        $table->timestamps();
        $table->softDeletes();
    });
}

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('pakaians');
    }
};
