<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('transaksis', function (Blueprint $table) {
            $table->id();
            // ID Unik untuk Midtrans
            $table->string('order_id')->nullable()->unique(); 
            
            // Relasi
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->foreignId('pakaian_id')->constrained()->onDelete('cascade');
            
            // Data Penyewa
            $table->string('nama')->nullable();
            $table->string('ponsel')->nullable();
            $table->text('alamat')->nullable();
            
            // Detail Sewa
            $table->integer('lama')->nullable(); // Dalam hitungan hari
            $table->integer('jumlah')->default(1); 
            $table->date('tgl_pesan')->nullable();
            $table->date('tgl_mulai')->nullable();
            $table->date('tgl_selesai')->nullable();
            
            // Perhitungan Biaya
            $table->integer('total_sewa')->nullable();
            $table->integer('total_deposit')->nullable();
            $table->integer('total_bayar')->nullable(); // Total Sewa + Deposit
            
            // Status & Pembayaran
            $table->enum('status', ['WAIT', 'PROSES', 'DIKEMBALIKAN', 'SELESAI', 'BATAL'])->default('WAIT');
            $table->string('metode_pembayaran')->nullable(); 
            $table->string('snap_token')->nullable(); // Untuk menyimpan token Midtrans
            
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('transaksis');
    }
};