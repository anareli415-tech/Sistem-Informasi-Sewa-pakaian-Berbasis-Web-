<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
public function up(): void
{
    Schema::create('pembayarans', function (Blueprint $table) {
        $table->id();
        $table->foreignId('transaksi_id')->constrained('transaksis')->onDelete('cascade');
        $table->string('external_id'); // ID unik untuk Midtrans
        $table->string('metode'); // COD atau ONLINE
        $table->integer('nominal');
        $table->enum('status_pembayaran', ['PENDING', 'SUCCESS', 'FAILED'])->default('PENDING');
        $table->string('snap_token')->nullable();
        $table->timestamps();
    });
}
    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('pembayarans');
    }
};
