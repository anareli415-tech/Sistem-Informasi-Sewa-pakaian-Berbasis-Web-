<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Pakaian;

class DashboardController extends Controller
{
public function index()
    {
        // JANGAN REDIRECT LAGI DI SINI!
        // Langsung tampilkan view dashboard pelanggan
        $pakaians = Pakaian::latest()->take(8)->get(); 
        return view('dashboard.pelanggan', compact('pakaians'));
    }

    public function profile()
    {
        $user = Auth::user();
        return view('profile.index', compact('user'));
    }

    public function updateProfile(Request $request)
    {
        $request->validate([
            'name'        => 'required|string|max:255',
            'foto'        => 'nullable|image|mimes:jpg,jpeg,png|max:2048',
            'deskripsi'   => 'nullable|string',
        ]);

        $user = Auth::user();

        $user->name = $request->name;
        $user->deskripsi = $request->deskripsi;

        if ($request->hasFile('foto')) {
            if ($user->foto) {
                \Illuminate\Support\Facades\Storage::delete($user->foto);
            }
            $user->foto = $request->file('foto')->store('profile');
        }

        $user->save();

        return redirect()->route('profile')->with('success', 'Profil berhasil diperbarui');
    }
}
