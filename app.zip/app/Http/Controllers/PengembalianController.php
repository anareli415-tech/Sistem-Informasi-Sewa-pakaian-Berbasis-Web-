<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Transaksi;
use App\Models\Pengembalian;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class PengembalianController extends Controller
{
    /**
     * Menampilkan daftar sewa yang statusnya sedang dibawa pelanggan (PROSES)
     */
    public function index()
    {
        $penyewaan = Transaksi::with('pakaian')
            ->where('user_id', Auth::id())
            ->where('status', 'PROSES') // Hanya tampilkan yang statusnya sedang disewa
            ->latest()
            ->get();

        return view('pengembalian.index', compact('penyewaan'));
    }

    /**
     * Menyimpan data pengembalian (Resi & Kurir)
     */
    public function store(Request $request)
    {
        $request->validate([
            'transaksi_id' => 'required|exists:transaksis,id',
            'kurir' => 'required',
            'nomor_resi' => 'required',
            'kondisi' => 'required'
        ]);

        try {
            DB::beginTransaction();

            // 1. Simpan ke tabel pengembalians
            Pengembalian::create([
                'transaksi_id' => $request->transaksi_id,
                'tgl_kembali_aktual' => now(),
                'kondisi' => $request->kondisi,
                'denda' => 0,
                'catatan' => "Kurir: " . $request->kurir . " | No. Resi: " . $request->nomor_resi,
            ]);

            // 2. Update status transaksi menjadi 'DIKEMBALIKAN'
            // Artinya barang sedang di jalan menuju toko/admin
         
                // Di PengembalianController.php
$transaksi = Transaksi::find($request->transaksi_id);
$transaksi->update(['status' => 'DIKEMBALIKAN'
]); // Pastikan 'DIKEMBALIKAN' ada di migration
            
            DB::commit();
            return redirect()->route('pengembalian.index')->with('success', 'Informasi pengembalian berhasil dikirim! Mohon tunggu verifikasi admin.');

        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->back()->with('error', 'Gagal: ' . $e->getMessage());
        }
    }
}