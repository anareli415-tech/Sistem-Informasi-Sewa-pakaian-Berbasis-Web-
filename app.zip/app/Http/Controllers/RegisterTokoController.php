<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Toko;

class RegisterTokoController extends Controller
{
    public function create(Request $request)
    {
        $user_id = session('user_id'); // ambil user yang baru daftar
        return view('toko.register', compact('user_id'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'user_id'   => 'required|exists:users,id',
            'nama_toko' => 'required|string|max:255',
        ]);

        Toko::create([
            'user_id'   => $request->user_id,
            'nama_toko' => $request->nama_toko,
        ]);

        return redirect()->route('dashboard.penyedia')->with('success', 'Toko berhasil dibuat');
    }
}
