<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Kategori;
use App\Models\Pakaian;

class KategoriController extends Controller
{
    // Halaman index kategori
  public function index(Request $request)
{
    $search = $request->input('search');
    $kategoris = Kategori::all();

    // JIKA ADA SEARCH, kita arahkan ke tampilan GRID PRODUK (seperti tampilan show)
    if ($search) {
        $pakaians = Pakaian::with('user')
            ->where('nama_pakaian', 'like', "%{$search}%")
            ->orWhere('jenis', 'like', "%{$search}%")
            ->latest()
            ->get();

        $kategoriNama = "Hasil Pencarian: " . $search;

        // Kita arahkan ke view show tapi isinya hasil search
        return view('kategori.show', compact('pakaians', 'kategoriNama', 'kategoris', 'search'));
    }

    // Tampilan awal (pilihan kategori) jika tidak ada search
    return view('kategori.index', compact('kategoris'));
}

    // Show pakaian berdasarkan kategori
    public function show($slug)
    {
        $kategoris = Kategori::all(); // ambil semua kategori untuk navbar dsb

        $slugClean = str_replace('-', '/', $slug);

        // Ambil pakaian di kategori ini
        $pakaians = Pakaian::with('user')
            ->where('jenis', $slugClean)
            ->get();

        // Ambil nama kategori dari array statis
        $kategoriNama = $kategoris[$slug] ?? ucfirst($slugClean);

        return view('kategori.show', [
            'pakaians' => $pakaians,
            'kategoriNama' => $kategoriNama,
            'kategoris' => $kategoris,
        ]);
    }
}
