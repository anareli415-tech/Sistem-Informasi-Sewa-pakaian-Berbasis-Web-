<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Transaksi;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class LaporanController extends Controller
{
  public function index(Request $request)
{
    $start = $request->start;
    $end = $request->end;
    $userId = auth()->id(); // ID Penyedia yang sedang login

    // Filter: Hanya ambil transaksi yang produknya (pakaian) milik penyedia ini
    $query = Transaksi::whereHas('pakaian', function($q) use ($userId) {
        $q->where('user_id', $userId);
    })->whereNotIn('status', ['WAIT', 'BATAL']);

    if ($start && $end) {
        $query->whereBetween('tgl_pesan', [$start, $end]);
    }

    $transaksi = $query->latest()->get();

    // Kalkulasi Stats khusus untuk transaksi milik penyedia ini saja
    $totalTransaksi = $transaksi->count();
    $totalPendapatan = $transaksi->sum('total_sewa');
    $totalDepositDitahan = $transaksi->where('status', '!=', 'SELESAI')->sum('total_deposit');

    return view('laporan.index', compact(
        'transaksi', 'start', 'end', 
        'totalTransaksi', 'totalPendapatan', 'totalDepositDitahan'
    ));

    }
}