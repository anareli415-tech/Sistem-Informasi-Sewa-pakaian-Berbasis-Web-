<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Toko;
use Illuminate\Support\Facades\Hash;

class RegisterController extends Controller
{
    // tampilkan form register
    public function index()
    {
        return view('register.index');
    }

    // proses register
    public function store(Request $request)
    {
        $request->validate([
            'email' => 'required|email|unique:users,email',
            'password' => 'required|min:6',
            'role' => 'required|in:pelanggan,penyedia',
        ]);

        if ($request->role === 'pelanggan') {
            $request->validate(['nama' => 'required|string|max:255']);

            $user = User::create([
                'name' => $request->nama,
                'email' => $request->email,
                'password' => Hash::make($request->password),
                'role' => 'pelanggan',
            ]);

            return redirect()->route('login')->with('success','Akun pelanggan berhasil dibuat');

        } else { // penyedia
            $request->validate(['nama_toko' => 'required|string|max:255']);

            $user = User::create([
                'name' => $request->nama_toko, // di kolom name tetap bisa
                'email' => $request->email,
                'password' => Hash::make($request->password),
                'role' => 'penyedia',
            ]);

            // buat toko
            Toko::create([
                'user_id' => $user->id,
                'nama_toko' => $request->nama_toko,
            ]);

            return redirect()->route('login')->with('success','Akun penyedia & toko berhasil dibuat');
        }
    }
}
