<?php

namespace App\Http\Controllers;

use App\Models\Transaksi;
use App\Models\Pakaian;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class TransaksiController extends Controller
{
    public function index()
    {
        $transaksis = Transaksi::with(['pakaian', 'user'])
            ->latest()
            ->get();

        return view('transaksi.index', compact('transaksis'));
    }

    public function show($id)
    {
        $transaksi = Transaksi::with(['pakaian', 'user'])->findOrFail($id);
        return view('transaksi.show', compact('transaksi'));
    }

    public function riwayatPakaian($id)
    {
        $pakaian = Pakaian::findOrFail($id);

        $pelangganSewa = Transaksi::where('pakaian_id', $id)
            ->latest()
            ->get();

        return view('pakaian.riwayat', compact('pakaian', 'pelangganSewa'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'pakaian_id' => 'required|exists:pakaians,id',
            'nama'       => 'required|string|max:255',
            'ponsel'     => 'required|string',
            'alamat'     => 'required|string',
            'lama'       => 'required|integer|min:1',
            'jumlah'     => 'required|integer|min:1',
            'tgl_mulai'  => 'required|date',
        ]);

        // ✅ CAST AMAN (INI FIX UTAMANYA)
        $lama   = (int) $request->lama;
        $jumlah = (int) $request->jumlah;

        DB::beginTransaction();
        try {
            $pakaian = Pakaian::findOrFail($request->pakaian_id);

            if ($pakaian->stok < $jumlah) {
                return back()->with('error', 'Stok tidak mencukupi');
            }

            $totalSewa    = $pakaian->harga * $jumlah * $lama;
            $totalDeposit = $pakaian->deposit * $jumlah;
            $totalBayar   = $totalSewa + $totalDeposit;

            $transaksi = Transaksi::create([
                'user_id'       => auth()->id(),
                'pakaian_id'    => $pakaian->id,
                'nama'          => $request->nama,
                'ponsel'        => $request->ponsel,
                'alamat'        => $request->alamat,
                'lama'          => $lama,
                'jumlah'        => $jumlah,
                'tgl_pesan'     => now(),
                'tgl_mulai'     => $request->tgl_mulai,
                'tgl_selesai'   => Carbon::parse($request->tgl_mulai)->addDays($lama),
                'total_sewa'    => $totalSewa,
                'total_deposit' => $totalDeposit,
                'total_bayar'   => $totalBayar,
                'status'        => 'WAIT',
            ]);

            // ✅ decrement HARUS integer
            $pakaian->decrement('stok', $jumlah);

            DB::commit();
            return redirect()->route('pembayaran.index', $transaksi->id);

        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', $e->getMessage());
        }
    }

    public function updateStatus(Request $request, $id)
    {
        $request->validate([
            'status' => 'required|in:WAIT,PROSES,SELESAI,BATAL'
        ]);

        DB::beginTransaction();
        try {
            $transaksi = Transaksi::findOrFail($id);
            $pakaian   = Pakaian::find($transaksi->pakaian_id);

            if (
                in_array($request->status, ['SELESAI', 'BATAL']) &&
                !in_array($transaksi->status, ['SELESAI', 'BATAL'])
            ) {
                if ($pakaian) {
                    $pakaian->increment('stok', (int) $transaksi->jumlah);
                }
            }

            $transaksi->update([
                'status' => $request->status
            ]);

            DB::commit();
            return back()->with('success', 'Status berhasil diupdate');

        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', $e->getMessage());
        }
    }
}
