<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Transaksi;
use Illuminate\Support\Facades\Auth;

class RiwayatController extends Controller
{
    public function index()
    {
        // Ambil SEMUA transaksi milik user login, urutkan dari yang terbaru dipesan
        $riwayats = Transaksi::with('pakaian')
            ->where('user_id', Auth::id())
            ->orderBy('created_at', 'desc') 
            ->get();

        return view('riwayat.index', compact('riwayats'));
    }
}