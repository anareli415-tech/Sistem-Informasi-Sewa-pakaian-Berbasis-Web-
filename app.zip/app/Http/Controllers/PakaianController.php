<?php

namespace App\Http\Controllers;

use App\Models\Pakaian;
use App\Models\Transaksi; // Wajib di-import untuk menarik data penyewa
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class PakaianController extends Controller
{
    /**
     * Menampilkan daftar pakaian
     */
    public function index()
    {
        $pakaians = Pakaian::with('transaksis')
            ->where('user_id', auth()->id()) 
            ->get();

        return view('pakaian.index', compact('pakaians'));
    }

    /**
     * FITUR RIWAYAT/DAFTAR PENYEWA (INI YANG TADI KURANG)
     */
    public function riwayat($id)
    {
        // 1. Ambil data pakaian
        $pakaian = Pakaian::where('user_id', auth()->id())->findOrFail($id);

        // 2. Ambil data transaksi/pelanggan yang menyewa pakaian ini
        // Pastikan variabelnya bernama $pelangganSewa agar sesuai dengan Blade Anda
        $pelangganSewa = Transaksi::where('pakaian_id', $id)
            ->orderBy('created_at', 'desc')
            ->get();

        return view('pakaian.riwayat', compact('pakaian', 'pelangganSewa'));
    }

    /**
     * Menampilkan form tambah pakaian
     */
    public function create()
    {
        return view('pakaian.create');
    }

    /**
     * Menyimpan data pakaian baru
     */
    public function store(Request $request)
    {
        $request->validate([
            'nama_pakaian' => 'required|string|max:255',
            'jenis'        => 'required',
            'ukuran'       => 'required',
            'stok'         => 'required|numeric',
            'harga'        => 'required|integer|min:1',
            'deposit'      => 'required|integer|min:0',
            'deskripsi'    => 'required',
            'foto'         => 'required|image|mimes:jpeg,png,jpg|max:2048',
        ]);

        $path = $request->file('foto')->store('pakaian', 'public');

        Pakaian::create([
            'user_id'      => auth()->id(),
            'nama_pakaian' => $request->nama_pakaian,
            'jenis'        => $request->jenis,
            'ukuran'       => implode(',', $request->ukuran),
            'stok'         => $request->stok,
            'harga'        => $request->harga,
            'deposit'      => $request->deposit,
            'deskripsi'    => $request->deskripsi,
            'foto'         => $path,
        ]);

        return redirect()->route('pakaian.index')->with('success', 'Pakaian berhasil ditambahkan!');
    }

    public function edit($id)
    {
        $pakaian = Pakaian::where('user_id', auth()->id())->findOrFail($id);
        return view('pakaian.edit', compact('pakaian'));
    }

    public function update(Request $request, $id)
    {
        $pakaian = Pakaian::where('user_id', auth()->id())->findOrFail($id);

        $request->validate([
            'nama_pakaian' => 'required|string|max:255',
            'jenis'        => 'required',
            'ukuran'       => 'required',
            'stok'         => 'required|integer|min:0',
            'harga'        => 'required|integer|min:1',
            'deposit'      => 'required|integer|min:0',
            'deskripsi'    => 'required',
            'foto'         => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
        ]);

        $data = $request->all();

        if ($request->hasFile('foto')) {
            if ($pakaian->foto) {
                Storage::disk('public')->delete($pakaian->foto);
            }
            $data['foto'] = $request->file('foto')->store('pakaian', 'public');
        }

        $pakaian->update($data);

        return redirect()->route('pakaian.index')->with('success', 'Data pakaian berhasil diperbarui!');
    }

    public function show($id)
    {
        $pakaian = Pakaian::findOrFail($id);
        return view('pakaian.show', compact('pakaian'));
    }

    public function destroy($id)
    {
        $pakaian = Pakaian::where('user_id', auth()->id())->findOrFail($id);
        
        if ($pakaian->foto) {
            Storage::disk('public')->delete($pakaian->foto);
        }

        $pakaian->delete();

        return redirect()->route('pakaian.index')->with('success', 'Pakaian berhasil dihapus!');
    }
}