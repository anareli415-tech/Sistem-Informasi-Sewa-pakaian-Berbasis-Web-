<?php

namespace App\Http\Controllers;
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    public function index()
    {
        return view('login.index');
    }

    public function proses(Request $request)
    {
        $credentials = $request->validate([
            'email' => 'required|email',
            'password' => 'required'
        ]);

        if(Auth::attempt($credentials)){
            $request->session()->regenerate();
            $role = Auth::user()->role;

            if($role === 'pemilik') return redirect()->route('dashboard.pemilik');
            if($role === 'penyedia') return redirect()->route('dashboard.penyedia');
            if($role === 'pelanggan') return redirect()->route('dashboard.pelanggan');

            Auth::logout();
            return back()->withErrors(['email'=>'Role user tidak dikenali.']);
        }

        return back()->withErrors(['email'=>'Email atau password salah'])->onlyInput('email');
    }

    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return redirect()->route('login');
    }
}
