<?php

namespace App\Http\Controllers;

use App\Models\Transaksi;
use Illuminate\Http\Request;
use Midtrans\Config;
use Midtrans\Snap;

class PembayaranController extends Controller
{
    public function __construct()
    {
        Config::$serverKey    = config('midtrans.serverKey');
        Config::$isProduction = config('midtrans.isProduction');
        Config::$isSanitized  = config('midtrans.isSanitized');
        Config::$is3ds        = config('midtrans.is3ds');
    }

    public function index($id)
    {
        $transaksi = Transaksi::with('pakaian')->findOrFail($id);

        if (!$transaksi->order_id) {
            $newOrderId = 'RENT-' . $transaksi->id . '-' . time();
            $transaksi->update(['order_id' => $newOrderId]);
            $transaksi->order_id = $newOrderId;
        }

        // Gunakan total_bayar sesuai yang ada di TransaksiController@store
        $totalTagihan = (int) $transaksi->total_bayar;
        $jumlahItem = (int) $transaksi->jumlah;
        
        // Midtrans butuh harga per unit (total / jumlah)
        $pricePerUnit = $totalTagihan / $jumlahItem;

        $params = [
            'transaction_details' => [
                'order_id'     => $transaksi->order_id, 
                'gross_amount' => $totalTagihan,
            ],
            'customer_details' => [
                'first_name' => $transaksi->nama,
                'email'      => auth()->user()->email,
                'phone'      => $transaksi->ponsel,
            ],
            'item_details' => [[
                'id'       => $transaksi->pakaian_id,
                'price'    => (int) $pricePerUnit,
                'quantity' => $jumlahItem,
                'name'     => substr($transaksi->pakaian->nama_pakaian, 0, 50),
            ]]
        ];

        try {
            $snapToken = Snap::getSnapToken($params);
            
            // Simpan snap_token ke database agar bisa dipanggil di view
            $transaksi->update(['snap_token' => $snapToken]);

            return view('pembayaran.index', [
                'transaksi' => $transaksi,
                'snapToken' => $snapToken,
                'jumlah'    => $jumlahItem
            ]);
        } catch (\Exception $e) {
            return "Midtrans Error: " . $e->getMessage();
        }
    }

    public function bayar(Request $request)
    {
        $transaksi = Transaksi::findOrFail($request->transaksi_id);
        $transaksi->update([
            'metode_pembayaran' => $request->metode,
            'status' => $request->metode === 'COD' ? 'WAIT' : 'PROSES'
        ]);

        // Jika ini dipanggil via AJAX di view pembayaran
        return response()->json(['success' => true]);
    }
}