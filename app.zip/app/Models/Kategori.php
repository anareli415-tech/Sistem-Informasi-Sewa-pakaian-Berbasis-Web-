<?php

namespace App\Models;

class Kategori
{
    // Enum kategori sama seperti migration pakaian
    public static function all()
    {
        return [
            'formal' => 'Formal',
            'adat/tradisional' => 'Adat/Tradisional',
            'pesta' => 'Pesta',
            'kasual' => 'Kasual',
            'kostum/cosplay' => 'Kostum/Cosplay',
            'olahraga' => 'Olahraga',
        ];
    }
}
