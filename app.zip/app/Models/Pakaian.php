<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Pakaian extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'nama_pakaian',
        'jenis',
        'ukuran',
        'stok',
        'harga',
        'deposit',
        'deskripsi',
        'foto',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    // ✅ RELASI RIWAYAT SEWA
    public function transaksis()
    {
        return $this->hasMany(Transaksi::class, 'pakaian_id');
    }
}
