<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Transaksi extends Model
{
    use SoftDeletes;

 protected $fillable = [
    'user_id',
    'pakaian_id',
    'order_id',      // Tambahkan ini
    'snap_token',    // Tambahkan ini
    'nama',
    'ponsel',
    'alamat',
    'lama',
    'jumlah',
    'tgl_pesan',
    'tgl_mulai',
    'tgl_selesai',
    'total_sewa',
    'total_deposit',
    'total_bayar',
    'status',
    'metode_pembayaran',
];

    public function pakaian()
    {
        return $this->belongsTo(Pakaian::class, 'pakaian_id');
    }

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }
}