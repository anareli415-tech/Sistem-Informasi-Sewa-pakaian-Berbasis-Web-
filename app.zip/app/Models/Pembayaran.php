<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Pembayaran extends Model
{
    protected $fillable = [
        'transaksi_id', 'external_id', 'metode', 'nominal', 'status_pembayaran', 'snap_token'
    ];

    public function transaksi()
    {
        return $this->belongsTo(Transaksi::class);
    }
}