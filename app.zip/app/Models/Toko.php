<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Toko extends Model
{
    use HasFactory;

    // Kolom yang boleh diisi (Mass Assignment)
    protected $fillable = [
        'user_id', 
        'nama_toko', 
        'status'
    ];

    /**
     * RELASI KE USER
     * Satu toko dimiliki oleh satu User (Penyedia)
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * RELASI KE PAKAIAN
     * Karena tabel 'pakaians' kamu menggunakan 'user_id' sebagai pemilik,
     * kita hubungkan 'user_id' di tabel Toko ke 'user_id' di tabel Pakaian.
     */
    public function pakaian()
    {
        // Parameter: (Model, foreign_key_di_pakaian, local_key_di_toko)
        return $this->hasMany(Pakaian::class, 'user_id', 'user_id');
    }

    /**
     * RELASI KE TRANSAKSI (Melalui Pakaian)
     * Ini digunakan untuk menghitung omset toko secara otomatis.
     * Mencari transaksi yang pakaiannya milik user_id toko ini.
     */
    public function transaksis()
    {
        return $this->hasManyThrough(
            Transaksi::class, 
            Pakaian::class, 
            'user_id',    // Foreign key di tabel Pakaian
            'pakaian_id', // Foreign key di tabel Transaksi
            'user_id',    // Local key di tabel Toko
            'id'          // Local key di tabel Pakaian
        );
    }
}